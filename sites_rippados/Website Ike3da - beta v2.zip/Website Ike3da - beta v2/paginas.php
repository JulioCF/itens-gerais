<?php
$pg = isset( $_GET['pg'] ) ? $_GET['pg'] : null;
switch ( $pg ){

	case 'downloads':
	include "downloads.php";
	break;

	case 'infos':
	include "infos.php";
	break;
	
	case 'vip':
	include "vip.php";
	break;

	default:
	include ("home.php");
	break;

}
?>