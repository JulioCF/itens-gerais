<?php
session_start();
if (empty($_SESSION['usuario_id'])){
 echo "Acesso negado!";
 exit;
}else{
include('config/conexao.php');

$usuario_id   = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];
}
?>
<?php
// PEGA OS DADOS DO USU�RIO

$query = "SELECT * FROM tbl_usuarios where id = '$usuario_id'";
    $resultado = mysql_query ($query);
	$campo = mysql_fetch_array ($resultado);   
	$usuario_nome = $campo ['nome'];  

$sign = "ike3da";
?>


<html>
<head>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<title>�rea Administrativa</title>
</head>
<style type="text/css">
body { width: 100%; margin:0; padding:0; background-color:#000; text-align:center; background: url(imags/bg-topo.png) center top no-repeat; font: 12px tahoma; color:#FFF; }
#topo-2 { margin: 0 auto; height: 260px; }
#banner { margin: 0 auto; width: 410px; height: 253px; background-image:url(imags/logo.png);}
/* ------------- */
#bemvindo { margin: 0 auto; margin-top: 10px; width: 300px; height: 40px; background: url(imags/bg-png.png) repeat; }
#menuadmin { margin: 0 auto; width: 100%; height: 45px; margin-top: 20px; background: url(imags/bg-png.png) repeat;}
#menuzin { margin: auto; width: 820px; margin-right: 10px; margin-top: 10px;}
ul.menuadmin2 { text-align: center; margin-top: 10px; margin-right:100px;}
ul.menuadmin2 li { padding: 0 50px 0 20px; display: inline;}
ul.menuadmin2 li a { text-decoration: none; font: bold 12px Tahoma, Arial; color:#d4d4d4; }
ul.menuadmin2 li a:hover { text-decoration: none; font: bold 12px Tahoma, Arial; color:#d5872d; }
/*---------------*/
#sistems { width: 80%; margin: 0 auto; margin-top: 10px; background:url(imags/bg-png.png) repeat; } 
#baixo { width: 100%; height: 100px; margin-top: 40px; }
#baixo a { text-decoration:none; color:#CCC; }
#baixo a:hover { text-decoration:none; color:#F90; }
#baixo a:visited { text-decoration:none; color:#BBB; }
#quadro { margin:0 auto; width: 350px; background-color:#050505; border:#070707 1px solid; }
</style>
<body>
<div id="body2">
<div id="topo-2">
<div id="banner"></div>
</div>
<div id="bemvindo">
<div style="height:10px;"></div>
<span style="font: 15px tahoma; ">Seja bem-vindo, <b><?php echo "$usuario_nome"; ?></b>.</span>
</div>

<div id="menuadmin">

<div style="height:5px;"></div>
			<ul class="menuadmin2">
            	<li><a href="?pg=noticias_cadastrar">Cadastrar Not&iacute;cia</a></li>
                <li><a href="?pg=noticias_listar">Listar Not&iacute;cias</a></li>
                <li><a href="logout.php">Sair</a></li>   
            </ul>   

</div>

<div id="sistems">
<?php include "pages.php"; ?>
</div>
<div id="baixo">
<div id="quadro">
<div style="height:10px;"></div>
<span style="font: 11px tahoma; ">Sistema de Not�cias desenvolvido por: <a href="http://forum.cronus-emulator.com/index.php?/user/2885-ike3da/" target="_blank"><b><?php echo "$sign"; ?></b></a></span><br>
<span style="font: 11px tahoma; ">Favor n�o retirar os cr�ditos.</span>
<div style="height:10px;"></div>
</div>
</div>
</div>
</body>
</html>