<?php
session_start();
session_unset();
session_destroy();
?>
<html><HEAD><TITLE></TITLE></HEAD>
<script>document.location = 'index.php'</script>
</head><body>
</body></html>

