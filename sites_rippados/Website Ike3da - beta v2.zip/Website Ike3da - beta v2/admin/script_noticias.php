<?php session_start(); ?>
<?php
if (!$_SESSION) session_start();
if (empty($_SESSION['usuario_id'])) {
 echo "Acesso negado!";
 exit;
}else{
include('config/conexao.php');

$usuario_id   = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];
}
?>
<?php
// PEGA OS DADOS DO USU�RIO

$query = "SELECT * FROM tbl_usuarios where id = '$usuario_id'";
    $resultado = mysql_query ($query);
	$campo = mysql_fetch_array ($resultado);   
	$usuario_nome = $campo ['nome'];  

?>

<?php

$acao = $_GET['acao'];

switch ($acao) {

case "cadastrar":

function trocar_acentos ($nome_arquivo)
{
		$nome_arquivo = str_replace(' ','_',$nome_arquivo);
		$nome_arquivo = str_replace('�','a',$nome_arquivo);
		$nome_arquivo = str_replace('�','a',$nome_arquivo);
		$nome_arquivo = str_replace('�','e',$nome_arquivo);
		$nome_arquivo = str_replace('�','e',$nome_arquivo);
		$nome_arquivo = str_replace('�','i',$nome_arquivo);
		$nome_arquivo = str_replace('�','i',$nome_arquivo);
		$nome_arquivo = str_replace('�','o',$nome_arquivo);
		$nome_arquivo = str_replace('�','o',$nome_arquivo);
		$nome_arquivo = str_replace('�','u',$nome_arquivo);
		$nome_arquivo = str_replace('�','u',$nome_arquivo);
		$nome_arquivo = strtolower($nome_arquivo);

		return $nome_arquivo;
}



$nome_arquivo = trocar_acentos ($_FILES['nome_arquivo']['name']);
$nome_arquivo_extensao = substr($nome_arquivo,strpos($nome_arquivo,'.')+1,strlen($nome_arquivo)-strpos($nome_arquivo,'.'));
$nome_arquivo_tamanho = $_FILES['nome_arquivo']['size'];
$nome_arquivo_descricao = $_POST['nome_arquivo_descricao'];
$nome_arquivo_data = date_default_timezone_set('America/Sao_Paulo');


		$uploaddir = "../imagens/noticias/";
		$data = time();
		
        if ($nome_arquivo != ""){
		if (file_exists($uploaddir.$nome_arquivo))
		{
			$nome_arquivo = mktime()."_".$nome_arquivo;
		}
		}



           move_uploaded_file($_FILES['nome_arquivo']['tmp_name'], $uploaddir . $nome_arquivo);

$titulo                  = $_POST['titulo'];
$descricao               = $_POST['descricao'];
//$destaque                = $_POST['destaque'];
$autor               	  = $_POST['autor'];
$status                  = $_POST['status'];
$msg                     = $_POST['msg'];
$msg                     = preg_replace("/\r\n|\n|\r/", '<br>', $msg);
$data_publicacao         = date("d/m/Y");

if (empty($titulo)) {
	echo '<script>alert("Preencha os campos corretamente.");</script>';
    echo '<script>history.back(-2)</script>';
}
else {
$query = "insert into tbl_noticias(titulo, descricao, autor, msg, nome_arquivo, data, status) values ('$titulo', '$descricao', '$autor', '$msg', '$nome_arquivo', '$data_publicacao', '$status')";
$rs= mysql_query($query);

?>

<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("\n Not�cia cadastrada com sucesso!")</SCRIPT>
<SCRIPT language="JavaScript">window.location.href="principal.php";</SCRIPT>

<?php

break;
}

case "editar":

$id_noticia           = $_POST['id_noticia'];
$titulo			      = $_POST['titulo'];
$descricao            = $_POST['descricao'];
$autor              = $_POST['autor'];
$msg                  = $_POST['msg'];
$msg                  = preg_replace("/\r\n|\n|\r/", '<br>', $msg);
$data                 = $_POST['data'];
$status               = $_POST['status'];


$nome_arquivo_file = $_FILES['nome_arquivo'];
$contar = count($nome_arquivo_file['name']);
$ok = 0;
$erro = 0;
for($i = 0; $i < $contar; $i++){
$nome_arquivo = $nome_arquivo_file['name'][$i];
$tmp = $nome_arquivo_file['tmp_name'][$i];
if(!empty($nome_arquivo)){




        function trocar_acentos2 ($nome_arquivo){
		$nome_arquivo = str_replace(' ','_',$nome_arquivo);
		$nome_arquivo = str_replace('�','a',$nome_arquivo);
		$nome_arquivo = str_replace('�','a',$nome_arquivo);
		$nome_arquivo = str_replace('�','e',$nome_arquivo);
		$nome_arquivo = str_replace('�','e',$nome_arquivo);
		$nome_arquivo = str_replace('�','i',$nome_arquivo);
		$nome_arquivo = str_replace('�','i',$nome_arquivo);
		$nome_arquivo = str_replace('�','o',$nome_arquivo);
		$nome_arquivo = str_replace('�','o',$nome_arquivo);
		$nome_arquivo = str_replace('�','o',$nome_arquivo);
        $nome_arquivo = str_replace('�','o',$nome_arquivo);
		$nome_arquivo = str_replace('�','u',$nome_arquivo);
		$nome_arquivo = str_replace('�','u',$nome_arquivo);
		$nome_arquivo = strtolower($nome_arquivo);

		return $nome_arquivo;
		}



        $nome_arquivo = trocar_acentos2 ($_FILES['nome_arquivo']['name']);
        $nome_arquivo_extensao = substr($nome_arquivo,strpos($nome_arquivo,'.')+1,strlen($nome_arquivo)-strpos($nome_arquivo,'.'));
        $nome_arquivo_tamanho = $_FILES['nome_arquivo']['size'];
        $nome_arquivo_descricao = $_POST['nome_arquivo_descricao'];
        $nome_arquivo_data = date('d/m/Y');

		$querydel = "select * from tbl_noticias where id_noticia='$id_noticia'";
        $rsdel = mysql_query ($querydel);

        $campodel = mysql_fetch_array($rsdel);
        $nome_arquivo_antigo = $campodel['nome_arquivo'];

        if ($rsdel){
        $uploaddir_antigo = "../imagens/noticias/";

    	if ($nome_arquivo_antigo != ""){
    	if (file_exists($uploaddir_antigo.$nome_arquivo_antigo)){
        unlink ($uploaddir_antigo.$nome_arquivo_antigo);
        }
        }
        }

         copy($_FILES['nome_arquivo']['tmp_name'], $uploaddir_antigo . $nome_arquivo);
         $query = "update tbl_noticias SET nome_arquivo = '$nome_arquivo' where id_noticia='$id_noticia'";
         $rs= mysql_query ($query);
        }
}
        
$data = date('d/m/Y');

$query2 = "update tbl_noticias SET
           titulo               = '$titulo',
           descricao            = '$descricao',
		   destaque             = '$destaque',
           autor              = '$autor',
           msg                  = '$msg',
           data                 = '$data',
           status               = '$status'
           
           where id_noticia='$id_noticia'";
           
$rs2    = mysql_query($query2);

?>

<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("\n Not�cia alterada com sucesso!\n Atualize a p�gina.")</SCRIPT>
<SCRIPT language="JavaScript">window.close();</SCRIPT>

<?php


break;


case "excluir":

$id_noticia = $_GET['id_noticia'];

$query="select * from tbl_noticias where id_noticia ='$id_noticia'";
$rs = mysql_query($query);
while($row = mysql_fetch_array($rs)){
$nome_arquivo = $row['nome_arquivo'];
}

$query2 = "delete from tbl_noticias where id_noticia = '$id_noticia'";
$rs    = mysql_query($query2);

if ($rs){
	$uploaddir = "../imagens/noticias/";

	if ($nome_arquivo != "") {unlink ($uploaddir.$nome_arquivo);}

?>

<SCRIPT LANGUAGE="JavaScript" TYPE="text/javascript"> alert ("\n Not�cia exclu�da com sucesso!")</SCRIPT>
<SCRIPT language="JavaScript">window.location.href="principal.php";</SCRIPT>

<?php
     
}
break;
}

?>
