<?php ob_start(); ?>
<?php
if (!$_SESSION) session_start();
if (empty($_SESSION['usuario_id'])) {
 echo "Acesso negado!";
 exit;
}else{
include('config/conexao.php');

$usuario_id   = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];
}
?>
<?php
// PEGA OS DADOS DO USU�RIO
$query = "SELECT * FROM tbl_usuarios where id = '$_SESSION'";
$resultado = mysql_query($query); 
	$campo = mysql_fetch_array ($resultado);
	$usuario_nome = $campo ['nome'];
?>