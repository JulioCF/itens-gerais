<?php
	// ATEN��O!!
   // ALTERE OS CAMPOS ABAIXO COMO MOSTRA NA DESCRI��O, CASO N�O CONSIGA, ADD: ike3da@hotmail.com 
   
$database="localhost"; // SERVIDOR 
$dbname="db"; // SEU BANCO DE DADOS
$usuario="root"; // USU�RIO DO MYSQL
$dbsenha="pass"; // SENHA DO MYSQL - SE N�O TIVER SENHA, DEIXE EM BRANCO.

$conexao=mysql_connect ($database, $usuario, $dbsenha);
if($conexao){
      if (mysql_select_db($dbname, $conexao)){ print "";
      }else{ print "N�o foi poss�vel selecionar o Banco de Dados"; }
}else{ print "Erro ao conectar o MySQL"; }
?>
