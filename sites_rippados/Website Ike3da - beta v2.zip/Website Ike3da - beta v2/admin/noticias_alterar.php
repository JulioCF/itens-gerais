<?php session_start(); ?>
<?php
if (!$_SESSION) session_start();
if (empty($_SESSION['usuario_id'])) {
 echo "Acesso negado!";
 exit;
}else{
include('config/conexao.php');

$usuario_id   = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];
}
?>
<?php
// PEGA OS DADOS DO USU�RIO
$query = "SELECT * FROM tbl_usuarios where id = '$_SESSION'";
$resultado = mysql_query($query); 
	$campo = mysql_fetch_array ($resultado);
	$usuario_nome = $campo ['nome'];
?>

<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<script language="javascript" type="text/javascript" src="javascript.js"></script>

<script type="text/javascript">

   _editor_url = "htmlarea/";

   _editor_lang = "en";

</script>

<script type="text/javascript" src="htmlarea.js"></script>    

<SCRIPT src="javascript/jscripts.js"></SCRIPT>


<style type="text/css">
body { margin:0; padding:0; background-color:#000; text-align:left; background-repeat:no-repeat; font: 12px tahoma; color:#FFF; }
input.cadastra{ margin-top: 10px; width: 120px; height: 30px; }

</style>

<SCRIPT language=JavaScript type=text/JavaScript>

<!--

function MM_jumpMenu(targ,selObj,restore){ //v3.0

  eval(targ+".location='"+selObj.options[selObj.selectedIndex].value+"'");

  if (restore) selObj.selectedIndex=0;

}

//-->

</SCRIPT>



<SCRIPT src="imagens/extranet/jscripts.js"></SCRIPT>


<div style="text-align:left; margin: 0 auto; height: 20px;"></div>
<div style="text-align:center; width: 400px;"> <span style="font:bold 24px tahoma; color: #d5872d;"> Alterar Not�cia </span> </div>
<div style="text-align:center; margin: 0 auto; height: 20px;"></div>
<div style="text-align:left; width: 400px; margin-left: 30px;">
<form action="script_noticias.php?acao=editar" Method="post" enctype="multipart/form-data">
                                      <table width="300" border="0" cellpadding="2" cellspacing="2" bordercolor="#000" bgcolor="#000">
  <tr>
    <td><span style="font: 14px tahoma;">T&iacute;tulo:</span> <span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(M�ximo de 75 caracteres permitidos.) </span> </td>
  </tr>
  <?php
$id_noticia = $_GET['id_noticia'];
$query = "select * from tbl_noticias where id_noticia = '$id_noticia'";
$resultado = mysql_query($query);
$row = mysql_fetch_array($resultado);
$titulo_noticia               = $row['titulo'];
$descricao                    = $row['descricao'];
$destaque                     = $row['destaque'];
$autor                        = $row['autor'];
$msg                          = $row['msg'];
$nome_arquivo                 = $row['nome_arquivo'];
$data                         = $row['data'];
$status                       = $row['status'];
?>
  <tr>
    <td><input name="titulo" type="text" id="titulo" size="50" maxlength="75"  value='<?php echo $titulo_noticia; ?>'></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Descri��o</span> <span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(M�ximo de 100 caracteres permitidos.) </span> </td>
  </tr>
  <tr>
    <td><input name="descricao" type="text" id="descricao" size="50" value='<?php echo $descricao; ?>'></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Banner atual</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;"></span></td>
  </tr>
   <tr>
	<td><img src="../imagens/noticias/<?php if ($nome_arquivo != ""){echo $nome_arquivo;}else{ echo 'nao_disponivel.png';}?>"></td>  </tr>
    <tr>
    <td><span style="font: 14px tahoma;">Alterar Banner</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Imagem do topo da not�cia. Utilizar no tamanho de at� 700x300px) </span></td>
  </tr>
  <tr>
    <td><input type="file" name="nome_arquivo" id="nome_arquivo" size="50"></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Not&iacute;cia</span> <span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">( <span style="color:#f43737;">Aten��o!</span> A tag "br" � a quebra de linha, n�o apague.) </span> </td>
  </tr>
  <tr>
    <td colspan="3">  
                                              <script language="JavaScript1.2" defer>
                                                    editor_generate('msg');
                                              </script>
   <textarea name="msg" cols="60" rows="18" border='1'><?php echo $msg; ?></textarea>
                                          </td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Ativo</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Selecione SIM para exibir a not�cia ou N�O para guard�-la.) </span></td>
  </tr>
  <tr>
    <td><select name='status' class='form-box2' id='ativo'>
                                              <?php if ($status != 'Sim'){echo "<option value='N�o' selected>N�o</option><option value='Sim'>Sim</option>";} 
											   else{echo "<option value='Sim' selected>Sim</option><option value='N�o'>N�o</option>";} ?>
                                            </select></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Autor</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Limite de 50 caracteres.) </span></td>
  </tr>
  <tr>
    <td><input name="autor" type="text" id="subtitulo" size="30" value="<?php echo $autor; ?>"></td>
  </tr>
  <tr>
     <td><?php if (!isset($id_noticia))
										  $id_noticia = ""; ?>
                                          
                                            <div align="left"> 
<input name="id_noticia" type="hidden" id="id_noticia" value="<?php echo $id_noticia; ?>">
                                              <input type=submit value="Alterar Not�cia" border=0 name='submit' class="cadastra">
                                            </div>
                                            </td>
  </tr>
</table>
                                </form>
                                </div>