<?php include "verifica.php"; ?>

<script language="javascript" type="text/javascript" src="javascript.js"></script>

<SCRIPT src="javascript/jscripts.js"></SCRIPT>

<script type="text/javascript">
   _editor_url = "htmlarea/";
   _editor_lang = "en";
</script>
<script type="text/javascript" src="htmlarea.js"></script>


<style type="text/css">
body { margin:0; padding:0; background-color:#000; text-align:center; background-repeat:no-repeat; font: 12px tahoma; color:#FFF; }
input.cadastra{ margin-top: 10px; width: 120px; height: 30px; }
</style>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<div style="text-align:center; margin: 0 auto; height: 20px;"></div>
<div style="text-align:center; margin: 0 auto; width: 600px;"> <span style="font:bold 24px tahoma; color: #d5872d;"> Cadastrar Not�cia </span> </div>
<div style="text-align:center; margin: 0 auto; height: 20px;"></div>
<div style="text-align:center; margin: 0 auto; width: 400px;">
<form action="script_noticias.php?acao=cadastrar" Method="post" enctype="multipart/form-data">
                                      <table width="300" border="0" cellpadding="2" cellspacing="2" bordercolor="#000" bgcolor="#000">
  <tr>
    <td><span style="font: 14px tahoma;">T&iacute;tulo:</span> <span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(M�ximo de 75 caracteres permitidos.) </span> </td>
  </tr>
  <tr>
    <td><input name="titulo" type="text" id="titulo" size="50" maxlength="75"></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Descri��o</span> <span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(M�ximo de 100 caracteres permitidos.) </span> </td>
  </tr>
  <tr>
    <td><input name="descricao" type="text" id="descricao" size="50" maxlength="100"></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Banner</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Imagem do topo da not�cia. Utilizar no tamanho de at� 700x300px) </span></td>
  </tr>
  <tr>
    <td><input type="file" name="nome_arquivo" id="nome_arquivo" size="50"></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Not&iacute;cia</span> <span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Permitido HTML. Sem limite de caracteres.) </span> </td>
  </tr>
  <tr>
    <td colspan="3">  
                                              <script language="JavaScript1.2" defer>
                                                    editor_generate('msg');
                                              </script>
   <textarea name="msg" cols="60" rows="18" border='1'></textarea>
                                          </td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Ativo</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Selecione SIM para exibir a not�cia ou N�O para guard�-la.) </span></td>
  </tr>
  <tr>
    <td><select name='status' id='ativo' >
                                              <option value="Sim" selected>Sim</option>
                                              <option value="N�o">N�o</option>
                                            </select></td>
  </tr>
  <tr>
    <td><span style="font: 14px tahoma;">Autor</span><span style="font: italic 11px tahoma; margin-left: 5px; color: #555;">(Limite de 50 caracteres.) </span></td>
  </tr>
  <tr>
    <td><input name="autor" type="text" id="subtitulo" size="30" maxlength="50"></td>
  </tr>
  <tr>
    <td><?php if (!isset($id_noticia))
										  $id_noticia = ""; ?>
                                          
                                            <div align="left;"> 
                                              <input name="id_noticia" type="hidden" value="<?php echo $id_noticia; ?>">
                                              <input type=submit value="Cadastrar Not�cia" border=0 name='submit' class="cadastra">
                                            </div>
                                            </td>
  </tr>
</table>
                                </form>
                                </div>