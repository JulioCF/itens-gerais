<?php session_start(); ?>
<?php
if (!$_SESSION) session_start();
if (empty($_SESSION['usuario_id'])) {
 echo "Acesso negado!";
 exit;
}else{
include('config/conexao.php');

$usuario_id   = $_SESSION['usuario_id'];
$usuario_nome = $_SESSION['usuario_nome'];
}
?>
<?php
// PEGA OS DADOS DO USU�RIO
$query = "SELECT * FROM tbl_usuarios where id = '$_SESSION'";
$resultado = mysql_query($query); 
	$campo = mysql_fetch_array ($resultado);
	$usuario_nome = $campo ['nome'];
?>
</script>
<link href="css/style.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="javascript/javascript.js"></script>
<style type="text/css">
body { background-color: #030303; font: #FFF; }
</style>
<body>
<?php

$id_noticia = $_GET['id_noticia'];
$query = "select * from tbl_noticias where id_noticia = '$id_noticia'";
$rs = mysql_query($query);
?>

        <?php
while($row = mysql_fetch_array($rs)){
$titulo_noticia       = $row['titulo'];
$descricao            = $row['descricao'];
$destaque             = $row['destaque'];
$autor              = $row['autor'];
$msg                  = $row['msg'];
$nome_arquivo         = $row['nome_arquivo'];
$data                 = $row['data'];
$status               = $row['status'];
}

  ?>
  
  
  <div style="text-align: center; margin-top: 20px;">
<div style="">
<span style="font:bold 23px tahoma, arial; color:#d78f32;"><?php echo $titulo_noticia; ?></span>
</div>
<div style="">
<span style="text-align: center; font: 11px tahoma, arial; color:#CCC;"><?php echo $descricao; ?></span>
</div>
<div style="height:20px;"></div>
<img src="../imagens/noticias/<?php if ($nome_arquivo != ""){echo $nome_arquivo;}else{ echo "nao_disponivel.png";}?>">
<div style="height:20px;"></div>
<div style="text-align: left; margin: 0 auto; width: 80%;">
<span style="text-align: left; font: 11px tahoma, arial; color:#CCC;"><?php echo $msg;?></span>
</div>
<div style="height:20px;"></div>
<div style="height:20px;">
                  
        <div style="height:20px;"><span style="text-align:center; font: 10px tahoma, arial; color:#BBB;">Situa��o: <b><?php if ($status != 'N�o'){ echo "<span style='color:#83c930;'>Ativa</span>";}else{echo "<span style='color:#f43737;'>Inativa</span>";} ?></span></b></span></div>
<span style="text-align:center; font: 10px tahoma, arial; color:#BBB;">Postado por: <b><span style="color: #d5872d;"><?php echo $autor; ?></span></b> - Data: <b><?php echo $data; ?></b></span>
</div>
