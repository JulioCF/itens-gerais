<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Área Administrativa</title>
</head>
<style type="text/css">
body { margin:0; padding:0; background-color:#000; text-align:center; background-image:url(imags/bg-topo.png); background-position:center top; background-repeat:no-repeat; font: 12px tahoma; color:#FFF; }
input { height: 30px; width: 150px; }
input#botao { margin-top: 10px; width: 100px; }
#form-enter { background:url(imags/bg-login.png) no-repeat; margin: 0 auto; width: 260px;height: 170px; }
#topo-2 { margin: 0 auto; height: 300px; }
#banner { margin: 0 auto; width: 410px; height: 253px; background-image:url(imags/logo.png);}
</style>
<body>
<div id="topo-2">
<div id="banner"></div>
</div>

<div id="form-enter">
<div style="height: 10px; "></div>
<TABLE cellSpacing=0 cellPadding=0 width=231 align=center border=0>
  <TBODY> 
  <TR> 
  
    <TD width=330 height=150> 
    <center><SPAN style="font: bold 22px tahoma, arial; color:#FFF; margin-right:;">Acesso Restrito</SPAN></center>
    <br>
      <FORM action='inc/autenticacao.rotinas.php' method=post>
        <TABLE cellSpacing=0 cellPadding=0 width=225 align=right border=0>
          <TBODY> 
          <TR> 
            <TD width=57 height=27> 
              <DIV align=right><SPAN style="font: 15px tahoma, arial; color:#FFF; margin-right: 10px;">Login:</SPAN></DIV>
            </TD>
            <TD width=173 height=27> 
              <INPUT size=20 name='usuario'>
            </TD>
          </TR>
          <TR> 
            <TD height=25> 
              <DIV align=right><SPAN style="font: 15px tahoma, arial; color:#FFF; margin-right: 10px;">Senha:</SPAN></DIV>
            </TD>
            <TD height=25> 
              <INPUT type='password' size=20 name='senha'>
            </TD>
          </TR>
          <TR> 
            <TD colSpan=2 height=25> 
              <DIV align=center> 
                <input type='hidden' name="enviado" value="posted">
                <INPUT type=submit id="botao" value="Entrar" name=Submit>
              </DIV>
            </TD>
          </TR>
          </TBODY>
        </TABLE>
        <DIV class=style7 align=center><BR>
          <BR>
        </DIV>
      </FORM>
      <DIV align=right><SPAN class=style7></SPAN></DIV>
    </TD>
  </TR>
  </TBODY>
</TABLE>
</div>
</body>
</html>