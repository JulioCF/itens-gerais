<?php
$pg = isset( $_GET['pg'] ) ? $_GET['pg'] : null;
switch ( $pg ){

	case 'noticias_cadastrar':
	include "noticias_cadastrar.php";
	break;

	case 'noticias_listar':
	include "noticias_listar.php";
	break;
	
	default:
	include ("noticias_listar.php");
	break;

}
?>