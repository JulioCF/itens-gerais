<?php include "verifica.php"; ?>

<script language="JavaScript">
function Abrir_Pagina(URL) {

  var width = 850;
  var height = 740;

  var left = 550;
  var top = 150;

  window.open(URL,'janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');

}
</script>

<script language="JavaScript">
function Abrir2(URL) {

  var width = 600;
  var height = 740;

  var left = 600;
  var top = 150;

  window.open(URL,'janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');

}
</script>

<style type="text/css">
body { margin:0; padding:0; background-color:#000; text-align:center; background-repeat:no-repeat; font: 12px tahoma; color:#FFF; }

#listar { margin: 0 auto; width: 100%; }
#bars1 { text-align:center; height: 30px; }
span.titlez { font: bold 13px tahoma, arial; }
#bars2 { text-align:center; height: 30px; }
</style>

<?php
$query = "select * from tbl_noticias order by id_noticia desc";
$rs = mysql_query($query);
?>

<div id="listar">
<div id="title1"></div>

<table width="100%" border="0" cellpadding="2" cellspacing="2" class="textoVerdanaPreto">
                                                                <tr bgcolor="#CCC"> 
                                                                 <td width="11%" bgcolor="#111" > 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">Data</span></div>
                                                                  </td>
                                                                  <td width="7%" bgcolor="#111" > 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">Ativa</span></div>
                                                                  </td>
                                                                  <td width="11%" bgcolor="#111" > 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">Autor</span></div>
                                                                  </td>
                                                                  <td width="31%" bgcolor="#111" > 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">T&iacute;tulo</span></div>
                                                                  </td>
                                                                    <td width="8%" bgcolor="#111"> 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">Visualizar</span></div>
                                                                  </td>
                                                                  <td width="8%" bgcolor="#111"> 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">Editar</span></div>
                                                                  </td>
                                                                  <td width="8%" bgcolor="#111" > 
                                                                    <div id="bars1"><div style="height:8px;"></div><span class="titlez">Excluir</span></div>
                                                                  </td>
                                                                </tr>
                                                                <?php
while($row = mysql_fetch_array($rs)){

$data_noticia      = $row['data'];
  ?>

                                                                <tr bgcolor="#020202">
                                                                <td width="11%" bgcolor="#020202"> 
                                                                    <div id="bars2"><div style="margin: 10px;"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                                                    <?php echo $row["data"] ?>
                                                                  </font></div></div></td> 
                                                                  <td width="7%" bgcolor="#020202"> 
                                                                    <div id="bars2"><div style="margin: 10px;"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                                                    <?php echo $row["status"] ?>
                                                                  </font></div></div></td> 
                                                                <td width="11%" bgcolor="#020202"> 
                                                                    <div id="bars2"><div style="margin: 10px;"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                                                    <?php echo $row["autor"] ?>
                                                                  </font></div></div></td> 
                                                                  <td width="31%" bgcolor="#020202"> 
                                                                    <div id="bars2"><div style="margin: 10px;"><font size="1" face="Verdana, Arial, Helvetica, sans-serif"> 
                                                                    <?php echo $row["titulo"] ?>
                                                                  </font></div></div></td>
                                                                    <td> 
                                                                    <div id="bars2"><div style="margin-top:10px;">
                                                                    <a href="javascript:Abrir_Pagina('noticias_visualizar.php?id_noticia=<?php echo $row["id_noticia"] ?>');">
                                                                        <img src="imagens/ed_preview.gif" width="16" height="14" border="0">
                                                                    </a></div>
                                                                    </div>
                                                                  </td>
                                                                  <td> 
                                                                    <div id="bars2"><div style="margin: 10px;"><a href="javascript:Abrir2('noticias_alterar.php?id_noticia=<?php echo $row["id_noticia"] ?>');"><img src="imagens/ed_refresh.gif" width="16" height="16" border="0"></a></div></div>
                                                                  </td>
                                                                  <td> 
                                                                    <div id="bars2"><div style="margin: 10px;"><a href="script_noticias.php?acao=excluir&id_noticia=<?php echo $row["id_noticia"] ?>"><img src="imagens/ed_delete.gif" width="18" height="17" border="0"></a></div></div>
                                                                  </td>
                                                                </tr>
                                                                <?php } ?>
                                                              </table>
</div>