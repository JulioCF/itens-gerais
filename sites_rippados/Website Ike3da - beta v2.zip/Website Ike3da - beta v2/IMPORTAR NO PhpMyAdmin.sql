﻿
-- Versão do PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `undermin_db`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_noticias`
--

CREATE TABLE IF NOT EXISTS `tbl_noticias` (
  `id_noticia` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(70) NOT NULL,
  `descricao` varchar(100) NOT NULL DEFAULT '',
  `destaque` char(3) NOT NULL DEFAULT '',
  `autor` varchar(55) NOT NULL DEFAULT '',
  `msg` text NOT NULL,
  `nome_arquivo` varchar(100) NOT NULL DEFAULT '',
  `data` varchar(15) NOT NULL DEFAULT '',
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`id_noticia`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=72 ;

--
-- Extraindo dados da tabela `tbl_noticias`
--

INSERT INTO `tbl_noticias` (`id_noticia`, `titulo`, `descricao`, `destaque`, `autor`, `msg`, `nome_arquivo`, `data`, `status`) VALUES
(1, 'Inauguração do Sistema de Notícias', 'Distruibuido Gratuitamente por ike3da', '', 'ike3da', 'Obrigado por utilizar este script feito por mim.<br><br>MSN para contato: ike3da@hotmail.com<br>Abraços!', 'ike3da.png', '14/11/2011', 'Sim'),
(60, 'Notícia inativa', '', '', 'ike3da', 'Esta notícia não é exibida na index do site por estar marcada como "Não ativa" no campo abaixo.<br><br>Favor deletar esta notícia.<br><br>', '', '14/11/2011', 'Não');

-- --------------------------------------------------------

--
-- Estrutura da tabela `tbl_usuarios`
--

CREATE TABLE IF NOT EXISTS `tbl_usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL DEFAULT '',
  `login` varchar(150) NOT NULL DEFAULT '',
  `senha` varchar(50) NOT NULL DEFAULT '',
  `status` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Extraindo dados da tabela `tbl_usuarios`
--

INSERT INTO `tbl_usuarios` (`id`, `nome`, `login`, `senha`, `status`) VALUES
(1, 'SEUNOME', 'admin', 'admin', '1');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
