<?php header("Content-type: text/html; charset=iso-8859-1"); ?>
<html>
<head>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<link type="text/css" href="css.css" rel="stylesheet"  />
<title>ragnaCHAMPION - Criado por ike3da</title>
</head>

<body>
<div id="topo">
<div id="logo"> <img src="img/logo.png" border="0" /> </div><!--logo-->
</div><!--topo-->

<!--------------------------- MENU ----------------by ike3da----------------->
<div id="menu-bg">
    	<div id="menu">
        	<div style="height:20px;"></div>
        	<ul class="menu2">
            	<li><a href="?pg=home">HOME</a></li>
                <li><a href="?pg=downloads">DOWNLOADS</a></li>
                <li><a href="#">REGISTRO</a></li>
                <li><a href="?pg=infos">INFORMA&Ccedil;&Otilde;ES</a></li>
                <li><a href="#">FORUM</a></li>
                <li><a href="?pg=vip">DOA&Ccedil;&Otilde;ES</a></li>            
            </ul>        
        </div><!--menu-->
	</div><!--menu-bg-->

<!---------------------------/ MENU ----------------by ike3da------------------>
<div style="clear:both;"></div>

<!--------------------------- BANNER ----------------by ike3da------------------>
<div id="banner-rotativo"><?php include "banner-rotativo.php"; ?></div>
<!---------------------------/BANNER ----------------by ike3da------------------>
<div style="clear:both;"></div>
<!--------------------------- CONTEUDO -----------by ike3da-------------------->
<div id="conteudo">

    <div id="paginas">
    <div style="height:10px;"></div>
    
    <?php include "paginas.php"; ?>
    
    <div style="height:10px;"></div>
    </div><!--paginas-->
    
<!--------------------------- LATERAL  -----------by ike3da-------------------->
<div id="baselateral">

     <div id="lateral1">
     
     <div style="margin: auto;">
    <div style="height:10px;"></div> 
    
     <a href="#"><img src="img/comecejogar.jpg" width="270" height="150" border="0"></a>
     
     <div style="height:10px;"></div> 
     </div>
         
    </div><!--lateral-->

<!--------------------------- lateral 2 -----------by ike3da-------------------->

     <div id="lateral2">
     <div style="height:10px;"></div>
     
    	 <div id="title-page">
		<p class="titles">Lateral 2</p>
		</div>    
     
     <p> Preencha aqui como preferir</p>
     <div style="height:10px;"></div>      
    </div><!--lateral2-->
    
    
    
<!--------------------------- lateral 3 -----------by ike3da-------------------->

     <div id="lateral3">
     <div style="height:10px;"></div>
     
    	 <div id="title-page">
		<p class="titles">Lateral 3</p>
		</div>    
     
     <p> Preencha aqui como preferir</p>
     <div style="height:10px;"></div>      
    </div><!--lateral2-->
    
<!--------------------------- lateral 4 -----------by ike3da-------------------->
<div id="lateral4">
     <div style="height:10px;"></div>
     
    	 <div id="title-page">
		<p class="titles">Redes Sociais</p>
		</div>    
     
     <div id="twitter"><a href="#" target="_blank"><img src="img/twitter.png" width="270" height="70" border="0"></a></div>
     
     <div id="orkut"><a href="#" target="_blank"><img src="img/orkut.png" width="270" height="70" border="0"></a></div>
     <div id="facebook"><a href="#" target="_blank"><img src="img/facebook.png" width="270" height="70" border="0"></a></div>
     
       <div style="height:10px;"></div> 
    </div><!--lateral3-->

</div>
</div><!--conteudo-->

<div style="clear:both;"></div>
<div style="margin: 0 auto; width: 850px; height:10px;"></div> 
<div id="area-vote">

<div id="vote1"><a href="#"><img src="img/vote1.jpg" width="263" height="60" border="0"></a></div>
<div id="vote2"><a href="#"><img src="img/vote2.jpg" width="263" height="60"  border="0"></a></div>
<div id="vote3"><a href="#"><img src="img/vote3.jpg" width="263" height="60"  border="0"></a></div>

</div>
<!--------------------------- /CONTEUDO -------------by ike3da------------------>
<div style="clear:both;"></div>

<div id="vote-area">

</div>
<!--------------------------- RODAPE -------------by ike3da------------------>
<div style="clear:both;"></div>

<div id="rodape">
<div style="height:40px;"></div>
<div style="margin:0 auto; width: 245px; height: 60px; background-image:url(img/foot-logo.png);"></div>
<p class="rodape1">Website desenvolvido por <a href="http://forum.cronus-emulator.com/index.php?/user/2885-ike3da/" class="signature" target="_blank">ike3da</a> - Todos os direitos reservados.<br>
www.seuservidor.com.br</p>
    
</div>

<!--------------------------- / RODAPE -------------by ike3da------------------>
</body>
</html>