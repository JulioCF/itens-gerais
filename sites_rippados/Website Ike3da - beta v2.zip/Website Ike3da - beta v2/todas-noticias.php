
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">

<?php include('admin/config/conexao.php');  ?>

<script language="JavaScript">
function abrir(URL) {

  var width = 700;
  var height = 400;

  var left = 600;
  var top = 350;

  window.open(URL,'janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=yes, fullscreen=no');

}
</script>
<style type="text/css">
body { background-color: #000; }
a.link-news {  margin-left: 15px; text-decoration:none; font:  11px tahoma, arial; color:#d78f32; }
a.link-news:visited { margin-left: 15px; text-decoration:none; font:  11px tahoma, arial; color:#d78f32; }
a.link-news:hover {  margin-left: 15px; text-decoration:none; font:  11px tahoma, arial; color:#646464; }

p.titles { text-align:center; font: bold 26px Harabara, tahoma, arial; color:#d78f32; }
</style>

<div style="margin: 10px;">
    <p class="titles">Todas as Not&iacute;cias</p>

                                            <?php
                                            
                                            $query_noticias = "select * from tbl_noticias where status = 'Sim' ORDER BY id_noticia DESC limit 99";
                                            $rs_noticias    = mysql_query($query_noticias);
                                            
                                            while($campo_noticias = mysql_fetch_array($rs_noticias)){
                                            
                                            $id_noticia        = $campo_noticias['id_noticia'];
                                            $data_noticia      = $campo_noticias['data'];
                                            $descricao_noticia = $campo_noticias['descricao'];
											$titulo_noticia = $campo_noticias['titulo'];
                                            
                                            ?>
                                            
                                                                                        
                                             <div style="text-align: left;">
                                            <span style="margin-left: 10px; font: 11px tahoma, arial; color:#4793b8; "><?php echo $data_noticia;?></span> <A class="link-news" title='<?php echo $descricao_noticia; ?>' href="javascript:abrir('noticias-descricao.php?id_noticia=<?php echo $id_noticia; ?>');"> <?php echo $titulo_noticia; ?></A><br>

                                            </div>
                                            <?php } ?>
                                            
<br>

                              
</div>