<link type="text/css" href="css.css" rel="stylesheet"  />
   
    <div id="noticias">
    	<div id="noti-title"><p class="titles">�ltimas Not�cias</p></div>
        <div id="noti-content">
        <div style="height:1px;"></div>
        	<div style="margin-left:10px; margin-right:10px; margin-bottom:10px;">
        <?php include "noticias.php"; ?>
        </div></div>
    </div>
    
    <div id="ranking">
    	<div id="rank-title"></div>
    	<div id="rank-content"></div>
    </div>

