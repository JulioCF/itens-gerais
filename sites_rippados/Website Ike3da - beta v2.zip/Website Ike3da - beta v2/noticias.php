
<?php include('admin/config/conexao.php');  ?>

<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<script language="JavaScript">
function abrir(URL) {

  var width = 750;
  var height = 400;

  var left = 600;
  var top = 350;

  window.open(URL,'janela', 'width='+width+', height='+height+', top='+top+', left='+left+', scrollbars=yes, status=no, toolbar=no, location=no, directories=no, menubar=no, resizable=no, fullscreen=no');

}
</script>
<style type="text/css">
a.link-news {  margin-left: 15px; text-decoration:none; font:  11px tahoma, arial; color:#d5872d; }
a.link-news:visited { margin-left: 15px; text-decoration:none; font:  11px tahoma, arial; color:#d5872d; }
a.link-news:hover {  margin-left: 15px; text-decoration:none; font:  11px tahoma, arial; color:#646464; }

a.vertodas {  margin-top: 10px; text-decoration:none; font: bold 9px tahoma, arial; color:#4793b8; }
a.vertodas:hover { margin-top: 10px; text-decoration:none; font: bold 9px tahoma, arial; color:#464646; }
a.vertodas:visited {  margin-top: 10px; text-decoration:none; font: bold 9px tahoma, arial; color:#4793b8; }
</style>
<div style="">
                                            <?php //quando status = 'Sim'
                                            
                                            $query_noticias = "select * from tbl_noticias where status = 'Sim' ORDER BY id_noticia DESC limit 10";
                                            $rs_noticias    = mysql_query($query_noticias);
                                            
                                            while($campo_noticias = mysql_fetch_array($rs_noticias)){
                                            
                                            $id_noticia        = $campo_noticias['id_noticia'];
                                            $data_noticia      = $campo_noticias['data'];
                                            $descricao_noticia = $campo_noticias['descricao'];
											$titulo_noticia = $campo_noticias['titulo'];
                                            
                                            ?>
                                            
                                            <div style="text-align: left;">
                                            <div style="height:7px;"></div>
                                            <span style="margin-left: 10px; font: 11px tahoma, arial; color:#4793b8; "><?php echo $data_noticia;?></span> <A class="link-news" title='<?php echo $descricao_noticia; ?>' href="javascript:abrir('noticias-descricao.php?id_noticia=<?php echo $id_noticia; ?>');"> <?php echo $titulo_noticia; ?></A><br>

                                            </div>
                                            <?php } ?>
                                            
<br>

                              <div style="text-align:center"><A class="vertodas" href="javascript:abrir('todas-noticias.php');">Todas as not�cias</A></div>
</div>