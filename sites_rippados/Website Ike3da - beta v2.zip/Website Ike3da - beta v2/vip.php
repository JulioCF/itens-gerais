<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<link rel="stylesheet" href="pages.css" type="text/css" />
<style type="text/css">
body { background-color: #000; margin:0; padding: 0; text-align:center; }
p.titles { font: bold 23px harabara, tahoma, arial; color:#d78f32; }
</style>

<div id="title-page">
<p class="titles">Doa��es</p>
</div>

<div id="campotexto">
<!------- texto dentro dessa div -------->



Seu texto aqui.



<!------- n�o passar daqui -------->
</div>

<!------- n�o deletar abaixo -------->
<div style="height:5px; margin-top:10px;"></div>