<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<?php include('admin/config/conexao.php'); ?>
<style type="text/css">
body { background-color:#000; text-align: center; }
</style>
<title>Not�cias</title>
                        <?php
                        
                        $id_noticia = $_GET['id_noticia'];
                        $query_noticias = "select * from tbl_noticias where id_noticia = '$id_noticia' AND status = 'Sim'";
                        $rs_noticias    = mysql_query($query_noticias);
                        
                        $campo_noticias = mysql_fetch_array($rs_noticias);
                        
                        $id_noticia        = $campo_noticias['id_noticia'];
                        $data_noticia      = $campo_noticias['data'];
                        $titulo_noticia    = $campo_noticias['titulo'];
                        $descricao_noticia = $campo_noticias['descricao'];
                        $texto_noticia     = $campo_noticias['msg'];
                        $fonte_noticia     = $campo_noticias['autor'];
                        $imagem_noticia     = $campo_noticias['nome_arquivo'];
                        
                        ?>
<div style="margin: 0 auto; text-align: center; margin-top: 20px; width: 700px; position:relative;">
<div style="">
<span style="font:bold 23px tahoma, arial; color:#d5872d;"><?php echo $titulo_noticia; ?></span>
</div>
<div style="">
<span style="text-align: center; font: 11px tahoma, arial; color:#616161;"><?php echo $descricao_noticia; ?></span>
</div>
<div style="height:20px;"></div>
<?php if ($imagem_noticia){ echo "<img src='imagens/noticias/$imagem_noticia' align='center' border='0'>"; } ?>
<div style="height:20px;"></div>
<div style="text-align: left; margin: 0 auto; width: 80%;">
<span style="text-align: left; font: 11px tahoma, arial; color:#CCC;"><?php echo $texto_noticia; ?></span>
</div>
<div style="height:20px;"></div><span style="text-align:center; font: 10px tahoma, arial; color:#616161;">Postado por: <span style="color:d5872d";><?php if($fonte_noticia != ""){ echo $fonte_noticia; }else{ echo "n�o informado";} ?></span> - Data: <?php echo $data_noticia; ?> </span>
</div>