This is GRF Tool, the open source GRF utility.
You can find the GRF website at:
http://openkore.sourceforge.net/grftool/
The latest version and the source code can be found there.

grf.dll is libgrf, the open source library for reading and writing GRF archives.
For the source code, API documentation and a Win32 Software Development Kit (SDK),
go to the GRF Tool website.

At the moment, GRF Tool can preview, browse and extract files from GRF archives,
but it cannot add or remove files yet. If you're looking for a tool that can
do that, try Gryff, another open source GRF utility (which also uses libgrf):
http://hatsukoi.ff.st/grfworks/