<?php if(!defined('EFFICIENT_ROOT')) exit; ?>

        <img src="images/text/t02.png" alt="Licence and guarantee" /><br />

          <br />
          
          <?php echo message('legal_gravity'); ?><br />
          
          <br />
          
          <?php echo message('legal_erods'); ?>
          
          

