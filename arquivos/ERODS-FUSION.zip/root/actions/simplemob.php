<?php if(!defined('EFFICIENT_ROOT')) exit; 

    require('layout/mob/search_form_simple.php');

?>