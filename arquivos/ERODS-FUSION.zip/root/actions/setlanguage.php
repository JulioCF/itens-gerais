<?php if(!defined('EFFICIENT_ROOT')) exit; 

  


?>