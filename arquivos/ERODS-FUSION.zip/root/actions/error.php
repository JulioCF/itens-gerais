<?php if(!defined('EFFICIENT_ROOT')) exit;

  if(!isset($error)) $error = 'Uknown';
  include('layout/error.php');

?>