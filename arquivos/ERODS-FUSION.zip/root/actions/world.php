<?php if(!defined('EFFICIENT_ROOT')) exit; 

  include('layout/' . ACTION . '/' . ACTION . '.php');

?>