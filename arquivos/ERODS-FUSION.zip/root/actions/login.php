<?php if(!defined('EFFICIENT_ROOT')) exit;

  require('layout/user/login.php');

?>