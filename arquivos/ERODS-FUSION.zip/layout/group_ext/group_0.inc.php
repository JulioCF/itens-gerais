<?php if(!defined('EFFICIENT_ROOT')) exit; ?>

      <!-- Links: card images "point-n-click" -->
      <div style="position: relative;">
        <a href="?act=itemsearch&amp;cname=on&amp;name=Mastering+Card"><object style="position: absolute; left: 255px; top: 40px; width: 80px; height: 100px;"></object></a>
        <a href="?act=itemsearch&amp;cname=on&amp;name=Dark+Priest+Card"><object style="position: absolute; left: 180px; top: 50px; width: 70px; height: 50px;"></object></a>
        <a href="?act=itemsearch&amp;cname=on&amp;name=Leaf+Cat+Card"><object style="position: absolute; left: 185px; top: 120px; width: 70px; height: 80px;"></object></a>
        <a href="?act=itemsearch&amp;cname=on&amp;name=Marin+Card"><object style="position: absolute; left: 280px; top: 150px; width: 60px; height: 60px;"></object></a>
      </div>