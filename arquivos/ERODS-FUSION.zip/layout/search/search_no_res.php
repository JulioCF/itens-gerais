<?php if(!defined('EFFICIENT_ROOT')) exit; ?>

  <center>
    <table class="whitetable alignment1" style="width: 50%" cellspacing="1">
      <tr class="grayrow cd"><td><?php echo message('e_src_noRes'); ?></td></tr>
      <tr>
        <td><?php echo message('e_src_cont'); ?></td>
      </tr>
    </table>
  </center>
        
