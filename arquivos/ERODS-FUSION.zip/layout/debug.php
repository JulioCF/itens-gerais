<?php if(!defined("EFFICIENT_ROOT")) exit; ?>
 
   <table cellspacing="1" class="whitetable pageNavigation">
  
    <tr class="blackrow">
      <td><?php echo message('e_dhandler'); ?></td>
    </tr>
    
    <tr>
      <td><?php echo $debug; ?></td>
    </tr>
    
  </table>

