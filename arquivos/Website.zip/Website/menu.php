			<ul>
            	<li style="padding-left:0px;"><a href="index.php">Home</a></li>
            	<li><a href="hospedagem.php">Hospedagem</a></li>
            	<li><a href="dominios.php">Domínios</a></li>
            	<li><a href="streaming.php">Streaming</a></li>
            	<li><a href="atendimento.php">Atendimento</a></li>
            </ul>