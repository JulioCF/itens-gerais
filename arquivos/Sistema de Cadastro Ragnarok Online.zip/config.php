<?php
	
	include("class_php.php");

	// Conexão com o Database
	
	$_esj->_Conexao(
	
		"localhost", 	// Host Padrão [ localhost ]
		"root", 	 	// Usuário do host
		"", 			// Senha do host
		"ragnarok"		// Nome do database do seu servidor de Ragnarok
	
	);
	
	// Configuração para ganhar vip ao se cadastrar
	
	$leveVIP = $_esj->_levelVip("1");	// Level vip do seu servidor Padrão [ Level 1 ]  -  Valor 0 para desativar
	$diasVIP = $_esj->_Vip("3");		// Valor de dias vips ganho ao se cadastrar Padrão [ 3 dias ]  -  Valor 0 para desativar
	
	// Mensagem de sucesso ao se cadastrar
	$mensagemR = "Sua conta foi cadastrada com sucesso.";	// Mensagem que aparece quando se cadastrar no servidor
	
	// Configurações do sistema de registro
	
	$title = $_esj->_titleW("SeuRO - Sistema de cadastro");		// Titulo da pagina do sistema de registro do teu servidor
	$RO = $_esj->_rO("SeuRO");		// Nome do seu servidor
?>
