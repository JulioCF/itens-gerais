ET_SURPRISE = 0
ET_QUESTION = 1
ET_DELIGHT = 2
ET_THROB = 3
ET_SWEAT = 4
ET_AHA = 5
ET_FRET = 6
ET_ANGER = 7
ET_MONEY = 8
ET_THINK = 9
ET_SCISSOR = 10
ET_ROCK = 11
ET_WRAP = 12
ET_FLAG = 13
ET_BIGTHROB = 14
ET_THANKS = 15
ET_KEK = 16
ET_SORRY = 17
ET_SMILE = 18
ET_PROFUSELY_SWEAT = 19
ET_SCRATCH = 20
ET_BEST = 21
ET_STARE_ABOUT = 22
ET_HUK = 23
ET_O = 24
ET_X = 25
ET_HELP = 26
ET_GO = 27
ET_CRY = 28
ET_KIK = 29
ET_CHUP = 30
ET_CHUPCHUP = 31
ET_HNG = 32
ET_OK = 33
ET_CHAT_PROHIBIT = 34
ET_INDONESIA_FLAG = 35
ET_STARE = 36
ET_HUNGRY = 37
ET_COOL = 38
ET_MERONG = 39
ET_SHY = 40
ET_GOODBOY = 41
ET_SPTIME = 42
ET_SEXY = 43
ET_COMEON = 44
ET_SLEEPY = 45
ET_CONGRATULATION = 46
ET_HPTIME = 47
ET_PH_FLAG = 48
ET_MY_FLAG = 49
ET_SI_FLAG = 50
ET_BR_FLAG = 51
ET_SPARK = 52
ET_CONFUSE = 53
ET_OHNO = 54
ET_HUM = 55
ET_BLABLA = 56
ET_OTL = 57
ET_DICE1 = 58
ET_DICE2 = 59
ET_DICE3 = 60
ET_DICE4 = 61
ET_DICE5 = 62
ET_DICE6 = 63
ET_INDIA_FLAG = 64
ET_LUV = 65
ET_FLAG8 = 66
ET_FLAG9 = 67
ET_MOBILE = 68
ET_MAIL = 69
ET_ANTENNA0 = 70
ET_ANTENNA1 = 71
ET_ANTENNA2 = 72
ET_ANTENNA3 = 73
ET_HUM2 = 74
ET_ABS = 75
ET_OOPS = 76
ET_SPIT = 77
ET_ENE = 78
ET_PANIC = 79
ET_WHISP = 80
ET_YUT1 = 81
ET_YUT2 = 82
ET_YUT3 = 83
ET_YUT4 = 84
ET_YUT5 = 85
ET_YUT6 = 86
ET_YUT7 = 87
MSI_EMOTION_SURPRISE = 544
MSI_EMOTION_QUESTION = 545
MSI_EMOTION_DELIGHT = 546
MSI_EMOTION_THROB = 547
MSI_EMOTION_BIGTHROB = 548
MSI_EMOTION_SWEAT = 549
MSI_EMOTION_AHA = 550
MSI_EMOTION_FRET = 551
MSI_EMOTION_ANGER = 552
MSI_EMOTION_MONEY = 553
MSI_EMOTION_THINK = 554
MSI_EMOTION_THANKS = 555
MSI_EMOTION_KEK = 556
MSI_EMOTION_SORRY = 557
MSI_EMOTION_SMILE = 558
MSI_EMOTION_PROFUSELY_SWEAT = 559
MSI_EMOTION_SCRATCH = 560
MSI_EMOTION_BEST = 561
MSI_EMOTION_STARE_ABOUT = 562
MSI_EMOTION_HUK = 563
MSI_EMOTION_O = 564
MSI_EMOTION_X = 565
MSI_EMOTION_HELP = 566
MSI_EMOTION_GO = 567
MSI_EMOTION_CRY = 568
MSI_EMOTION_KIK = 569
MSI_EMOTION_CHUP = 570
MSI_EMOTION_CHUPCHUP = 571
MSI_EMOTION_HNG = 572
MSI_EMOTION_OK = 573
MSI_EMOTION_STARE = 772
MSI_EMOTION_HUNGRY = 773
MSI_EMOTION_COOL = 774
MSI_EMOTION_MERONG = 775
MSI_EMOTION_SHY = 776
MSI_EMOTION_GOODBOY = 777
MSI_EMOTION_SPTIME = 778
MSI_EMOTION_SEXY = 779
MSI_EMOTION_COMEON = 780
MSI_EMOTION_SLEEPY = 781
MSI_EMOTION_CONGRATULATION = 782
MSI_EMOTION_HPTIME = 783
MSI_EMOTION_SPARK = 945
MSI_EMOTION_CONFUSE = 946
MSI_EMOTION_OHNO = 947
MSI_EMOTION_HUM = 948
MSI_EMOTION_BLABLA = 949
MSI_EMOTION_OTL = 950
MSI_EMOTION_ROCK = 1501
MSI_EMOTION_SCISSOR = 1502
MSI_EMOTION_WRAP = 1503
MSI_EMOTION_LUV = 1504
MSI_EMOTION_MOBILE = 1505
MSI_EMOTION_MAIL = 1506
MSI_EMOTION_ANTENNA0 = 1507
MSI_EMOTION_ANTENNA1 = 1508
MSI_EMOTION_ANTENNA2 = 1509
MSI_EMOTION_ANTENNA3 = 1510
MSI_EMOTION_HUM2 = 1511
MSI_EMOTION_ABS = 1512
MSI_EMOTION_OOPS = 1513
MSI_EMOTION_SPIT = 1514
MSI_EMOTION_ENE = 1515
MSI_EMOTION_PANIC = 1516
MSI_EMOTION_WHISP = 1517

EMOTION_ORDERLIST = {
	ET_SURPRISE,
	ET_QUESTION,
	ET_DELIGHT,
	ET_THROB,
	ET_BIGTHROB,
	ET_SWEAT,
	ET_AHA,
	ET_FRET,
	ET_ANGER,
	ET_MONEY,
	ET_THINK,
	ET_ROCK,
	ET_SCISSOR,
	ET_WRAP,
	ET_THANKS,
	ET_KEK,
	ET_SORRY,
	ET_SMILE,
	ET_PROFUSELY_SWEAT,
	ET_SCRATCH,
	ET_BEST,
	ET_STARE_ABOUT,
	ET_HUK,
	ET_O,
	ET_X,
	ET_HELP,
	ET_GO,
	ET_CRY,
	ET_KIK,
	ET_CHUP,
	ET_CHUPCHUP,
	ET_HNG,
	ET_OK,
	ET_STARE,
	ET_HUNGRY,
	ET_COOL,
	ET_MERONG,
	ET_SHY,
	ET_GOODBOY,
	ET_SPTIME,
	ET_SEXY,
	ET_COMEON,
	ET_SLEEPY,
	ET_CONGRATULATION,
	ET_HPTIME,
	ET_SPARK,
	ET_CONFUSE,
	ET_OHNO,
	ET_HUM,
	ET_BLABLA,
	ET_OTL,
	ET_LUV,
	ET_MOBILE,
	ET_MAIL,
	ET_ANTENNA1,
	ET_ANTENNA2,
	ET_ANTENNA3,
	ET_HUM2,
	ET_ABS,
	ET_OOPS,
	ET_SPIT,
	ET_ENE,
	ET_PANIC,
	ET_WHISP,
}
EmotionList = {}
EmotionMsgList = {}
--Group 1
InsertEmotionListTable(ET_SURPRISE, MSI_EMOTION_SURPRISE, 0)
InsertEmotionMsgListTable(ET_SURPRISE,c_GetMsgString(MSI_EMOTION_SURPRISE))
--Group 2
InsertEmotionListTable(ET_QUESTION, MSI_EMOTION_QUESTION, 1)
InsertEmotionMsgListTable(ET_QUESTION,c_GetMsgString(MSI_EMOTION_QUESTION))
--Group 3
InsertEmotionListTable(ET_DELIGHT, MSI_EMOTION_DELIGHT, 2)
InsertEmotionMsgListTable(ET_DELIGHT,c_GetMsgString(MSI_EMOTION_DELIGHT))
InsertEmotionMsgListTable(ET_DELIGHT,"/delight")
InsertEmotionMsgListTable(ET_DELIGHT,"/rlQma")
InsertEmotionMsgListTable(ET_DELIGHT,"/��")
--Group 4
InsertEmotionListTable(ET_THROB, MSI_EMOTION_THROB, 3)
InsertEmotionMsgListTable(ET_THROB,c_GetMsgString(MSI_EMOTION_THROB))
InsertEmotionMsgListTable(ET_THROB,"/heart")
InsertEmotionMsgListTable(ET_THROB,"/gkxm")
--Group 5
InsertEmotionListTable(ET_BIGTHROB, MSI_EMOTION_BIGTHROB, 4)
InsertEmotionMsgListTable(ET_BIGTHROB,c_GetMsgString(MSI_EMOTION_BIGTHROB))
--Group 6
InsertEmotionListTable(ET_SWEAT, MSI_EMOTION_SWEAT, 5)
InsertEmotionMsgListTable(ET_SWEAT,c_GetMsgString(MSI_EMOTION_SWEAT))
InsertEmotionMsgListTable(ET_SWEAT,"/sweat")
InsertEmotionMsgListTable(ET_SWEAT,"/Eka")
--Group 7
InsertEmotionListTable(ET_AHA, MSI_EMOTION_AHA, 6)
InsertEmotionMsgListTable(ET_AHA,c_GetMsgString(MSI_EMOTION_AHA))
InsertEmotionMsgListTable(ET_AHA,"/aha")
InsertEmotionMsgListTable(ET_AHA,"/dkgk")
--Group 8
InsertEmotionListTable(ET_FRET, MSI_EMOTION_FRET, 7)
InsertEmotionMsgListTable(ET_FRET,c_GetMsgString(MSI_EMOTION_FRET))
InsertEmotionMsgListTable(ET_FRET,"/fret")
InsertEmotionMsgListTable(ET_FRET,"/Wkwmd")
--Group 9
InsertEmotionListTable(ET_ANGER, MSI_EMOTION_ANGER, 8)
InsertEmotionMsgListTable(ET_ANGER,c_GetMsgString(MSI_EMOTION_ANGER))
InsertEmotionMsgListTable(ET_ANGER,"/ghk")
InsertEmotionMsgListTable(ET_ANGER,"/anger")
--Group 10
InsertEmotionListTable(ET_MONEY, MSI_EMOTION_MONEY, 9)
InsertEmotionMsgListTable(ET_MONEY,c_GetMsgString(MSI_EMOTION_MONEY))
InsertEmotionMsgListTable(ET_MONEY,"/money")
InsertEmotionMsgListTable(ET_MONEY,"/ehs")
--Group 11
InsertEmotionListTable(ET_THINK, MSI_EMOTION_THINK, 10)
InsertEmotionMsgListTable(ET_THINK,c_GetMsgString(MSI_EMOTION_THINK))
--Group 12
InsertEmotionListTable(ET_THANKS, MSI_EMOTION_THANKS, 15)
InsertEmotionMsgListTable(ET_THANKS,c_GetMsgString(MSI_EMOTION_THANKS))
InsertEmotionMsgListTable(ET_THANKS,"/��")
--Group 13
InsertEmotionListTable(ET_KEK, MSI_EMOTION_KEK, 16)
InsertEmotionMsgListTable(ET_KEK,c_GetMsgString(MSI_EMOTION_KEK))
--Group 14
InsertEmotionListTable(ET_SORRY, MSI_EMOTION_SORRY, 17)
InsertEmotionMsgListTable(ET_SORRY,c_GetMsgString(MSI_EMOTION_SORRY))
InsertEmotionMsgListTable(ET_SORRY,"/sorry")
--Group 15
InsertEmotionListTable(ET_SMILE, MSI_EMOTION_SMILE, 18)
InsertEmotionMsgListTable(ET_SMILE,c_GetMsgString(MSI_EMOTION_SMILE))
InsertEmotionMsgListTable(ET_SMILE,"/����")
InsertEmotionMsgListTable(ET_SMILE,"/��")
InsertEmotionMsgListTable(ET_SMILE,"/smile")
--Group 16
InsertEmotionListTable(ET_PROFUSELY_SWEAT, MSI_EMOTION_PROFUSELY_SWEAT, 19)
InsertEmotionMsgListTable(ET_PROFUSELY_SWEAT,c_GetMsgString(MSI_EMOTION_PROFUSELY_SWEAT))
--Group 17
InsertEmotionListTable(ET_SCRATCH, MSI_EMOTION_SCRATCH, 20)
InsertEmotionMsgListTable(ET_SCRATCH,c_GetMsgString(MSI_EMOTION_SCRATCH))
--Group 18
InsertEmotionListTable(ET_BEST, MSI_EMOTION_BEST, 21)
InsertEmotionMsgListTable(ET_BEST,c_GetMsgString(MSI_EMOTION_BEST))
InsertEmotionMsgListTable(ET_BEST,"/����")
InsertEmotionMsgListTable(ET_BEST,"/��")
--Group 19
InsertEmotionListTable(ET_STARE_ABOUT, MSI_EMOTION_STARE_ABOUT, 22)
InsertEmotionMsgListTable(ET_STARE_ABOUT,c_GetMsgString(MSI_EMOTION_STARE_ABOUT))
--Group 20
InsertEmotionListTable(ET_HUK, MSI_EMOTION_HUK, 23)
InsertEmotionMsgListTable(ET_HUK,c_GetMsgString(MSI_EMOTION_HUK))
InsertEmotionMsgListTable(ET_HUK,"/��")
--Group 21
InsertEmotionListTable(ET_O, MSI_EMOTION_O, 24)
InsertEmotionMsgListTable(ET_O,c_GetMsgString(MSI_EMOTION_O))
InsertEmotionMsgListTable(ET_O,"/o")
--Group 22
InsertEmotionListTable(ET_X, MSI_EMOTION_X, 25)
InsertEmotionMsgListTable(ET_X,c_GetMsgString(MSI_EMOTION_X))
InsertEmotionMsgListTable(ET_X,"/x")
--Group 23
InsertEmotionListTable(ET_HELP, MSI_EMOTION_HELP, 26)
InsertEmotionMsgListTable(ET_HELP,c_GetMsgString(MSI_EMOTION_HELP))
InsertEmotionMsgListTable(ET_HELP,"/����")
InsertEmotionMsgListTable(ET_HELP,"/help")
--Group 24
InsertEmotionListTable(ET_GO, MSI_EMOTION_GO, 27)
InsertEmotionMsgListTable(ET_GO,c_GetMsgString(MSI_EMOTION_GO))
--Group 25
InsertEmotionListTable(ET_CRY, MSI_EMOTION_CRY, 28)
InsertEmotionMsgListTable(ET_CRY,c_GetMsgString(MSI_EMOTION_CRY))
--Group 26
InsertEmotionListTable(ET_KIK, MSI_EMOTION_KIK, 29)
InsertEmotionMsgListTable(ET_KIK,c_GetMsgString(MSI_EMOTION_KIK))
InsertEmotionMsgListTable(ET_KIK,"/ű")
InsertEmotionMsgListTable(ET_KIK,"/��")
InsertEmotionMsgListTable(ET_KIK,"/����")
--Group 27
InsertEmotionListTable(ET_CHUP, MSI_EMOTION_CHUP, 30)
InsertEmotionMsgListTable(ET_CHUP,c_GetMsgString(MSI_EMOTION_CHUP))
--Group 28
InsertEmotionListTable(ET_CHUPCHUP, MSI_EMOTION_CHUPCHUP, 31)
InsertEmotionMsgListTable(ET_CHUPCHUP,c_GetMsgString(MSI_EMOTION_CHUPCHUP))
--Group 29
InsertEmotionListTable(ET_HNG, MSI_EMOTION_HNG, 32)
InsertEmotionMsgListTable(ET_HNG,c_GetMsgString(MSI_EMOTION_HNG))
--Group 30
InsertEmotionListTable(ET_OK, MSI_EMOTION_OK, 33)
InsertEmotionMsgListTable(ET_OK,c_GetMsgString(MSI_EMOTION_OK))
InsertEmotionMsgListTable(ET_OK,"/����")
--Group 31
InsertEmotionListTable(ET_STARE, MSI_EMOTION_STARE, 35)
InsertEmotionMsgListTable(ET_STARE,c_GetMsgString(MSI_EMOTION_STARE))
InsertEmotionMsgListTable(ET_STARE,"/��")
InsertEmotionMsgListTable(ET_STARE,"/e1")
--Group 32
InsertEmotionListTable(ET_HUNGRY, MSI_EMOTION_HUNGRY, 36)
InsertEmotionMsgListTable(ET_HUNGRY,c_GetMsgString(MSI_EMOTION_HUNGRY))
InsertEmotionMsgListTable(ET_HUNGRY,"/e2")
--Group 33
InsertEmotionListTable(ET_COOL, MSI_EMOTION_COOL, 37)
InsertEmotionMsgListTable(ET_COOL,c_GetMsgString(MSI_EMOTION_COOL))
InsertEmotionMsgListTable(ET_COOL,"/e3")
--Group 34
InsertEmotionListTable(ET_MERONG, MSI_EMOTION_MERONG, 38)
InsertEmotionMsgListTable(ET_MERONG,c_GetMsgString(MSI_EMOTION_MERONG))
InsertEmotionMsgListTable(ET_MERONG,"/e4")
--Group 35
InsertEmotionListTable(ET_SHY, MSI_EMOTION_SHY, 39)
InsertEmotionMsgListTable(ET_SHY,c_GetMsgString(MSI_EMOTION_SHY))
InsertEmotionMsgListTable(ET_SHY,"/��")
InsertEmotionMsgListTable(ET_SHY,"/e5")
--Group 36
InsertEmotionListTable(ET_GOODBOY, MSI_EMOTION_GOODBOY, 40)
InsertEmotionMsgListTable(ET_GOODBOY,c_GetMsgString(MSI_EMOTION_GOODBOY))
InsertEmotionMsgListTable(ET_GOODBOY,"/e6")
--Group 37
InsertEmotionListTable(ET_SPTIME, MSI_EMOTION_SPTIME, 41)
InsertEmotionMsgListTable(ET_SPTIME,c_GetMsgString(MSI_EMOTION_SPTIME))
InsertEmotionMsgListTable(ET_SPTIME,"/��")
InsertEmotionMsgListTable(ET_SPTIME,"/e7")
--Group 38
InsertEmotionListTable(ET_SEXY, MSI_EMOTION_SEXY, 42)
InsertEmotionMsgListTable(ET_SEXY,c_GetMsgString(MSI_EMOTION_SEXY))
InsertEmotionMsgListTable(ET_SEXY,"/e8")
--Group 39
InsertEmotionListTable(ET_COMEON, MSI_EMOTION_COMEON, 43)
InsertEmotionMsgListTable(ET_COMEON,c_GetMsgString(MSI_EMOTION_COMEON))
InsertEmotionMsgListTable(ET_COMEON,"/e9")
--Group 40
InsertEmotionListTable(ET_SLEEPY, MSI_EMOTION_SLEEPY, 44)
InsertEmotionMsgListTable(ET_SLEEPY,c_GetMsgString(MSI_EMOTION_SLEEPY))
InsertEmotionMsgListTable(ET_SLEEPY,"/��")
InsertEmotionMsgListTable(ET_SLEEPY,"/e10")
--Group 41
InsertEmotionListTable(ET_CONGRATULATION, MSI_EMOTION_CONGRATULATION, 45)
InsertEmotionMsgListTable(ET_CONGRATULATION,c_GetMsgString(MSI_EMOTION_CONGRATULATION))
InsertEmotionMsgListTable(ET_CONGRATULATION,"/����")
InsertEmotionMsgListTable(ET_CONGRATULATION,"/e11")
--Group 42
InsertEmotionListTable(ET_HPTIME, MSI_EMOTION_HPTIME, 46)
InsertEmotionMsgListTable(ET_HPTIME,c_GetMsgString(MSI_EMOTION_HPTIME))
InsertEmotionMsgListTable(ET_HPTIME,"/��")
InsertEmotionMsgListTable(ET_HPTIME,"/e12")
--Group 43
InsertEmotionListTable(ET_SPARK, MSI_EMOTION_SPARK, 51)
InsertEmotionMsgListTable(ET_SPARK,c_GetMsgString(MSI_EMOTION_SPARK))
InsertEmotionMsgListTable(ET_SPARK,"/e13")
--Group 44
InsertEmotionListTable(ET_CONFUSE, MSI_EMOTION_CONFUSE, 52)
InsertEmotionMsgListTable(ET_CONFUSE,c_GetMsgString(MSI_EMOTION_CONFUSE))
InsertEmotionMsgListTable(ET_CONFUSE,"/e14")
--Group 45
InsertEmotionListTable(ET_OHNO, MSI_EMOTION_OHNO, 53)
InsertEmotionMsgListTable(ET_OHNO,c_GetMsgString(MSI_EMOTION_OHNO))
InsertEmotionMsgListTable(ET_OHNO,"/�Ѽ�")
InsertEmotionMsgListTable(ET_OHNO,"/e15")
--Group 46
InsertEmotionListTable(ET_HUM, MSI_EMOTION_HUM, 54)
InsertEmotionMsgListTable(ET_HUM,c_GetMsgString(MSI_EMOTION_HUM))
InsertEmotionMsgListTable(ET_HUM,"/e16")
--Group 47
InsertEmotionListTable(ET_BLABLA, MSI_EMOTION_BLABLA, 55)
InsertEmotionMsgListTable(ET_BLABLA,c_GetMsgString(MSI_EMOTION_BLABLA))
InsertEmotionMsgListTable(ET_BLABLA,"/�ò��ò�")
InsertEmotionMsgListTable(ET_BLABLA,"/e17")
--Group 48
InsertEmotionListTable(ET_OTL, MSI_EMOTION_OTL, 56)
InsertEmotionMsgListTable(ET_OTL,c_GetMsgString(MSI_EMOTION_OTL))
InsertEmotionMsgListTable(ET_OTL,"/e18")
InsertEmotionMsgListTable(ET_OTL,"/otl")
--Group 49
InsertEmotionListTable(ET_ROCK, MSI_EMOTION_ROCK, 11)
InsertEmotionMsgListTable(ET_ROCK,c_GetMsgString(MSI_EMOTION_ROCK))
InsertEmotionMsgListTable(ET_ROCK,"/wnajr")
InsertEmotionMsgListTable(ET_ROCK,"/bawi")
InsertEmotionMsgListTable(ET_ROCK,"/qkdnl")
InsertEmotionMsgListTable(ET_ROCK,"/����")
--Group 50
InsertEmotionListTable(ET_SCISSOR, MSI_EMOTION_SCISSOR, 12)
InsertEmotionMsgListTable(ET_SCISSOR,c_GetMsgString(MSI_EMOTION_SCISSOR))
InsertEmotionMsgListTable(ET_SCISSOR,"/rkdnl")
InsertEmotionMsgListTable(ET_SCISSOR,"/gawi")
--Group 51
InsertEmotionListTable(ET_WRAP, MSI_EMOTION_WRAP, 13)
InsertEmotionMsgListTable(ET_WRAP,c_GetMsgString(MSI_EMOTION_WRAP))
InsertEmotionMsgListTable(ET_WRAP,"/qh")
InsertEmotionMsgListTable(ET_WRAP,"/bo")
--Group 52
InsertEmotionListTable(ET_LUV, MSI_EMOTION_LUV, 64)
InsertEmotionMsgListTable(ET_LUV,c_GetMsgString(MSI_EMOTION_LUV))
InsertEmotionMsgListTable(ET_LUV,"/e20")
--Group 53
InsertEmotionListTable(ET_MOBILE, MSI_EMOTION_MOBILE, 67)
InsertEmotionMsgListTable(ET_MOBILE,c_GetMsgString(MSI_EMOTION_MOBILE))
InsertEmotionMsgListTable(ET_MOBILE,"/e21")
--Group 54
InsertEmotionListTable(ET_MAIL, MSI_EMOTION_MAIL, 68)
InsertEmotionMsgListTable(ET_MAIL,c_GetMsgString(MSI_EMOTION_MAIL))
InsertEmotionMsgListTable(ET_MAIL,"/e22")
--Group 55
InsertEmotionListTable(ET_ANTENNA0, MSI_EMOTION_ANTENNA0, 69)
InsertEmotionMsgListTable(ET_ANTENNA0,c_GetMsgString(MSI_EMOTION_ANTENNA0))
InsertEmotionMsgListTable(ET_ANTENNA0,"/e23")
--Group 56
InsertEmotionListTable(ET_ANTENNA1, MSI_EMOTION_ANTENNA1, 70)
InsertEmotionMsgListTable(ET_ANTENNA1,c_GetMsgString(MSI_EMOTION_ANTENNA1))
InsertEmotionMsgListTable(ET_ANTENNA1,"/e24")
--Group 57
InsertEmotionListTable(ET_ANTENNA2, MSI_EMOTION_ANTENNA2, 71)
InsertEmotionMsgListTable(ET_ANTENNA2,c_GetMsgString(MSI_EMOTION_ANTENNA2))
InsertEmotionMsgListTable(ET_ANTENNA2,"/e25")
--Group 58
InsertEmotionListTable(ET_ANTENNA3, MSI_EMOTION_ANTENNA3, 72)
InsertEmotionMsgListTable(ET_ANTENNA3,c_GetMsgString(MSI_EMOTION_ANTENNA3))
InsertEmotionMsgListTable(ET_ANTENNA3,"/e26")
--Group 59
InsertEmotionListTable(ET_HUM2, MSI_EMOTION_HUM2, 73)
InsertEmotionMsgListTable(ET_HUM2,c_GetMsgString(MSI_EMOTION_HUM2))
InsertEmotionMsgListTable(ET_HUM2,"/e27")
InsertEmotionMsgListTable(ET_HUM2,"/��")
--Group 60
InsertEmotionListTable(ET_ABS, MSI_EMOTION_ABS, 74)
InsertEmotionMsgListTable(ET_ABS,c_GetMsgString(MSI_EMOTION_ABS))
InsertEmotionMsgListTable(ET_ABS,"/e28")
InsertEmotionMsgListTable(ET_ABS,"/��")
--Group 61
InsertEmotionListTable(ET_OOPS, MSI_EMOTION_OOPS, 75)
InsertEmotionMsgListTable(ET_OOPS,c_GetMsgString(MSI_EMOTION_OOPS))
InsertEmotionMsgListTable(ET_OOPS,"/e29")
InsertEmotionMsgListTable(ET_OOPS,"/��")
--Group 62
InsertEmotionListTable(ET_SPIT, MSI_EMOTION_SPIT, 76)
InsertEmotionMsgListTable(ET_SPIT,c_GetMsgString(MSI_EMOTION_SPIT))
InsertEmotionMsgListTable(ET_SPIT,"/e30")
InsertEmotionMsgListTable(ET_SPIT,"/��")
--Group 63
InsertEmotionListTable(ET_ENE, MSI_EMOTION_ENE, 77)
InsertEmotionMsgListTable(ET_ENE,c_GetMsgString(MSI_EMOTION_ENE))
InsertEmotionMsgListTable(ET_ENE,"/e31")
InsertEmotionMsgListTable(ET_ENE,"/Ż��")
--Group 64
InsertEmotionListTable(ET_PANIC, MSI_EMOTION_PANIC, 78)
InsertEmotionMsgListTable(ET_PANIC,c_GetMsgString(MSI_EMOTION_PANIC))
InsertEmotionMsgListTable(ET_PANIC,"/e32")
InsertEmotionMsgListTable(ET_PANIC,"/��Ȳ")
--Group 65
InsertEmotionListTable(ET_WHISP, MSI_EMOTION_WHISP, 79)
InsertEmotionMsgListTable(ET_WHISP,c_GetMsgString(MSI_EMOTION_WHISP))
InsertEmotionMsgListTable(ET_WHISP,"/e33")
InsertEmotionMsgListTable(ET_WHISP,"/������")
--Individual Start 1
InsertEmotionListTable(ET_FLAG, -1, 14)
InsertEmotionListTable(ET_CHAT_PROHIBIT, -1, 1000)
InsertEmotionListTable(ET_INDONESIA_FLAG, -1, 34)
InsertEmotionListTable(ET_PH_FLAG, -1, 47)
InsertEmotionListTable(ET_MY_FLAG, -1, 48)
InsertEmotionListTable(ET_SI_FLAG, -1, 49)
InsertEmotionListTable(ET_BR_FLAG, -1, 50)
--Individual End 1
--Group 66
InsertEmotionListTable(ET_DICE1, -1, 57)
InsertEmotionMsgListTable(ET_DICE1,"/dice")
InsertEmotionMsgListTable(ET_DICE1,"/e19")
InsertEmotionListTable(ET_DICE2, -1, 58)
InsertEmotionListTable(ET_DICE3, -1, 59)
InsertEmotionListTable(ET_DICE4, -1, 60)
InsertEmotionListTable(ET_DICE5, -1, 61)
InsertEmotionListTable(ET_DICE6, -1, 62)
--Individual Start 2
InsertEmotionListTable(ET_INDIA_FLAG, -1, 63)
InsertEmotionListTable(ET_FLAG8, -1, 65)
InsertEmotionListTable(ET_FLAG9, -1, 66)
--Individual End 2
--Group 67
InsertEmotionListTable(ET_YUT1, -1, 86)
InsertEmotionMsgListTable(ET_YUT1,"/��")
InsertEmotionMsgListTable(ET_YUT1,"/dbc")
InsertEmotionListTable(ET_YUT2, -1, 87)
InsertEmotionListTable(ET_YUT3, -1, 88)
InsertEmotionListTable(ET_YUT4, -1, 89)
InsertEmotionListTable(ET_YUT5, -1, 90)
InsertEmotionListTable(ET_YUT6, -1, 91)
InsertEmotionListTable(ET_YUT7, -1, 92)