LayerOow_F = {
	[JOBID.JT_MERCHANT] = {
		[58] = 1e-005,
		[59] = 1e-005,
		[60] = 1e-005,
		[61] = 1e-005,
	},
	[JOBID.JT_MAGICIAN] = {
		[81] = -1e-005,
		[86] = -1e-005,
	}
}
