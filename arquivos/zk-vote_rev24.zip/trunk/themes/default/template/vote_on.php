<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

echo "
	<div id=\"diag\" align=\"center\" style=\"background-color:#FFFF99;\">
		

				   <table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"100%\">
				   <tbody>
				   <tr>
				   <td width=\"70\">
				   <img src=\"themes/$theme/img/emblem-favorite.png\" class=\"reflect\" />
				   		</td>			
				  <td align=\"center\" valign=\"middle\" style=\"color:#333333;\">
				  Voto Aceptado.<br /> Gracias ^^<br /><br />

				<input name=\"login\" type=\"button\" onClick=\"action('list');\" value =\"Aceptar\">
				</td></tr></tbody> </table>

			  </div>"; 
 ?>