<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

echo '
<div id="footerBar" align="center">
	<table>
	<tr>
		<td width="370" align="center">
		Panel de Votaciones <a href="http://zk-vote.sourceforge.net/" TARGET="_blank" >ZK-Vote</a> - Creadores : <b>ZRO</b> y <b>Kaneda</b><br />
		<a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/3.0/" TARGET="_blank" ><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-sa/3.0/80x15.png" /></a><br />
		<img src="themes/css.gif">&nbsp;&nbsp;
		<img src="themes/xhtml.gif">&nbsp;&nbsp;
		<img src="themes/ajax.gif">&nbsp;&nbsp;
		<img src="themes/php.gif">&nbsp;&nbsp;
		<img src="themes/sql.gif">
		</td>
	</tr>
	</table>
</div>';
?>