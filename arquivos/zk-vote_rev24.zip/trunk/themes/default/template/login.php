<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

echo '
  <div id="login">
    <table width="490" height="148" border="0" cellpadding="0" cellspacing="0">
      <tr>
        <th colspan="5" align="left"><h2>// '.$GLOBALS[sitename].' - Panel de Votaciones.</h2>
          <br /></th>
      </tr>
      <tr>
        <td width="95" height="35" align="right" class="logText" >User :</td>
        <td width="180"><input class="imput"  id="userid" name="userid" type="text" value="" maxlength="50" /></td>
        <td width="215" rowspan="3" align="left" valign="top"><p>-Introduce los mismo datos que usas para entrar al Juego<br />
          <br />
          <a href="'.$GLOBALS[soporte].'" target="_blank"> - Si tienes dudas puedes consultar el Foro...</a></p></td>
      </tr>
      <tr>
        <td height="35" align="right"   class="logText">Password :</td>
        <td><input class="imput" id="user_pass" name="user_pass" type="password" value="" maxlength="50" /></td>
      </tr>
      <tr>
        <td  colspan="2" align="center"><input name="login" type="button" onclick="action(\'login\');" value ="Login" /></td>
      </tr>
    </table>
  </div>';	
	    
?>