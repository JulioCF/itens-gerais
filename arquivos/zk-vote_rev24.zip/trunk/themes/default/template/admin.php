<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

echo '
<div id="vote">
  <div id="vote_top"></div>
  <div id="vote_cont">
	<table border="0" cellspacing="0" cellpadding="8" id="topbox">
	<tr>
    	<td class="info" width="275">
	  	<h2>Panel Admin</h2>
	  	<div class="user">
	    <div align="center">Bienvenid@: <b>'. $_SESSION[username].'</b></div></div>
	  	<input name="lo" type="button" onclick="action(\'list\');" value ="Volver ... ">&nbsp;&nbsp;
	  	</td>
		<td valign="top" width="400">
		<input name="lo" type="button"  onclick="action(\'gm\');" value ="Principal">	
		<input name="lo" type="button"  onclick="admin(\'add\');" value ="Agregar Top">
		<input name="lo" type="button" onclick="admin(\'theme\');" value ="Cambiar Theme">
		<hr>
		<div id="blacon">';
		admin_list();
echo'	</div>
		</td>
    </tr>
	</table>
  	</div>
	<div id="vote_footer"></div>
</div>
</div>';




?>