<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/


echo '
<div id="vote">
    <div id="vote_top"></div>
    <div id="vote_cont">
	<table width="590"  border="0" cellspacing="0" cellpadding="8"> 
	<tr>
		<td width="240" valign="top" class="info">
		<h2>Informaciones</h2>
		<div class="user">
		<div align="center">Bienvenid@: <b>' . $_SESSION[username] . '</b></div><br/>
		<li><span>Total de Puntos :</span><strong>&nbsp;'.$point. '</strong></li>
		</div>';
		if( $_SESSION["gm"] >= $GLOBALS[mlevel]) {
echo ' 		<input name="lo" type="button" onclick="action(\'gm\');" value ="Panel Admin">';
		}
echo '	<input name="lo" type="button" onclick="action(\'logout\');" value ="Salir">
		<div id="invote"></div>
		<br />
		<div class="qLinks">
		<br />
		<p><b>Quick Links</b></p>
		<br />';
		top_list_il();
echo'	</div>
		</td>
        
		<td width="350" valign="top">
		<div class="topContent">';
		top_list();
echo'</div>
		</td>
	</tr>
	</table>
    </div>
    <div id="vote_footer"></div>
</div>';

?>