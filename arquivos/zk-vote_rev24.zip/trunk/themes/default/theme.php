<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

##################################################################
#                    Theme de la pagina                          #
##################################################################
$theme = "default";
#$color1 = "6EB5F0";
#$color2 = "3393E2";
#$color3 = "0099FF";
##################################################################

function theme_header(){
global $theme;					
	include("template/header.php");
}

function theme_login(){ 
global $theme;
	theme_header();
	include("template/login.php");
	include("template/footer.php");
}


function theme_vote_list() {
global $theme;
$point=points();
	theme_header();
	include("template/panel.php");
	include("template/footer.php");
}



function theme_admin(){
global $theme;
	theme_header();
	include("template/admin.php");
	include("template/footer.php");
}

function theme_out() {
global $theme;
	theme_header();
	include("themes/$theme/template/log_out.php");
	include("template/footer.php");
}

?>