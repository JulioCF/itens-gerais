<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

function head() {
global $sitename, $theme;
	$theme = get_theme();
	include("themes/$theme/theme.php");

	echo "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"> \n";
	echo "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n";
	echo "<head>\n";
	echo "<meta content=\"charset=iso-8859-1\" />\n";
	echo "<title>$sitename - ZK-Vote PANEL</title>\n";
	include("include/meta.php");
	//include("include/javascript.php");
	echo "<script type=\"text/javascript\" src=\"include/javascript.js\"></script>\n";
	if (file_exists("theme/$theme/images/favicon.ico")) {
		echo "<link REL=\"shortcut icon\" HREF=\"themes/$theme/images/favicon.ico\" TYPE=\"image/x-icon\">\n";
    }

// Detectando Navegador =====================================================================
		if(strpos($_SERVER["HTTP_USER_AGENT"], "Firefox"))			{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/moz_style.css\" TYPE=\"text/css\">\n";}
		elseif (strpos($_SERVER["HTTP_USER_AGENT"], "Chrome"))		{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/style.css\" TYPE=\"text/css\">\n";}
		elseif (strpos($_SERVER["HTTP_USER_AGENT"], "Safari"))		{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/style.css\" TYPE=\"text/css\">\n";}
		elseif (strpos($_SERVER["HTTP_USER_AGENT"], "MSIE"))		{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/ie_style.css\" TYPE=\"text/css\">\n";}
		elseif (strpos($_SERVER["HTTP_USER_AGENT"], "Presto"))		{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/ie_style.css\" TYPE=\"text/css\">\n";}
		elseif (strpos($_SERVER["HTTP_USER_AGENT"], "Konqueror"))	{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/style.css\" TYPE=\"text/css\">\n";}
		else
		{echo "<LINK REL=\"StyleSheet\" HREF=\"themes/$theme/style/ie_style.css\" TYPE=\"text/css\">\n";}
// ===========================================================================================

	echo "
	<script type=\"text/javascript\" src=\"http://ajax.googleapis.com/ajax/libs/mootools/1.2.2/mootools-yui-compressed.js\"></script>
	<script type=\"text/javascript\" src=\"js/sexylightbox.v2.2.mootools.js\"></script>
	<link rel=\"stylesheet\" href=\"js/sexylightbox.css\" type=\"text/css\" media=\"all\" />

	<script type=\"text/javascript\">
	window.addEvent('domready', function(){
    SexyLightbox = new SexyLightBox({color:'white'});
	});
	</script>";
	echo "\n</head>\n";	
	//theme_header();
	
}
	head();
	echo "<body>\n";  

?>
