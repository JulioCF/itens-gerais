<?php 

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/


session_start();
require_once("include/config.inc.php");
include("include/funciones.php");
//$theme = get_theme();
include("header.php");

$action = htmlspecialchars($_GET["action"]);

echo "<div id=\"cuerpo\">";
switch($action){
	case "login":
		if (!isset($_GET["userid"]) OR !isset($_GET["user_pass"]) )  {
			theme_login();
			die();
		}
		$userid = addslashes( mysql_real_escape_string($_GET['userid']) );
		$user_pass = addslashes( mysql_real_escape_string($_GET['user_pass']) );
		if ($md5 == 1 ) $user_pass=md5($user_pass);
		$query = "SELECT account_id, userid, user_pass, level  FROM login  WHERE userid = '$userid' AND user_pass = '$user_pass'";
		query($query);
		
		if($num != 0) {
			$account_id = $row['account_id'];
			$gm = $row['level'];
			$_SESSION["online"] = "1";
			$_SESSION["account_id"] = $account_id;
			$_SESSION["username"] = $userid;
			$_SESSION["password"] = $user_pass;
			$_SESSION["gm"] = $gm;
			theme_vote_list();
		}
		else {
			theme_login();	
		}
		
		break;
	
	case "gm":
		
		if( $_SESSION["online"] != "1" OR $_SESSION["gm"] != $GLOBALS[mlevel] ) {
			theme_login();
			die();
		}
		//AQUI EL CODIGO PARA a�adir nuevos tops o borrarlos
		$op = htmlspecialchars($_GET["op"]);
		switch($op){
			case "add":
				if( htmlspecialchars($_GET["sub"]) == "save"){
					$top_name = addslashes( mysql_real_escape_string($_GET['top_name']) );
					$top_url = addslashes( mysql_real_escape_string($_GET['top_url']) );
					$top_img = addslashes( mysql_real_escape_string($_GET['top_img']) );
					$query = "
					INSERT INTO vote_list (`name` ,`url` ,`img`)
					VALUES ('$top_name', '$top_url', '$top_img')";
					$result = mysql_query($query) or die(mysql_error());
					echo "<p>$top_name agregado exitosamente</p>";
				}
				admin_add();
			break;
			
			case "edit":
				if( htmlspecialchars($_GET["sub"]) == "update"){
					$id = addslashes( mysql_real_escape_string($_GET['id']) );
					$top_name = addslashes( mysql_real_escape_string($_GET['top_name']) );
					$top_url = addslashes( mysql_real_escape_string($_GET['top_url']) );
					$top_img = addslashes( mysql_real_escape_string($_GET['top_img']) );
					$query = "UPDATE vote_list SET name = '$top_name', url = '$top_url', img = '$top_img' WHERE id = '$id'";
					$result = mysql_query($query) or die(mysql_error());
					echo "<p>$top_name editado exitosamente</p>";
				}			
				admin_edit();
			break;				
			
			case "delte":
				if( htmlspecialchars($_GET["sub"]) == "delte"){
					$id = addslashes( mysql_real_escape_string($_GET['id']) );
					$query = "SELECT * FROM vote_list WHERE id = '$id'";
					query($query);
					
					if ($num != 0){
						$query = "DELETE FROM vote_list WHERE id='$id'";
						$result = mysql_query ($query);
						echo "Top borrado correctamente";
					}
				}
				else
				echo "No se ha borrado ningun top";
			break;
			
			case "theme":
				//Cambio de theme lectura de la directorio themes //
				$dir = "themes/";			
				echo "<select name=\"type\">";
				if ($dh = opendir($dir)) {
					while (($file = readdir($dh)) !== false) {
					if (is_dir ("$dir$file") && $file != '.' && $file != '..' && $file != '.svn') {
						echo "<option value=\"$file\">". $file ."</option>";
					}
				   
					}
					closedir($dh);
				}
				echo "</select>";	
			break;
			
			
			default:
				///Funcion llamada del theme
				theme_admin();
			break;
		
		}
		
	break;

	case "votar":
		if( $_SESSION["online"] != "1"  && !isset($_GET["op"]) ) {
			theme_login();
			die();
		}
		
		$id_top=addslashes( mysql_real_escape_string($_GET["op"]) );
		$account_id=addslashes( mysql_real_escape_string($_SESSION["account_id"] ));
		$ip=obtener_ip();
		$voteon = mysql_query("SELECT * FROM vote_list WHERE id = '$id_top'");
		$rows = mysql_num_rows($voteon);
		if (!$rows){ 
		
			echo "
			<div id=\"diag\" align=\"center\" style=\"	background-color:#EEEEEE; \">
			<p><b>Advertencia</b><br />
			Top NO VALIDO</p><br /><br />
			<input name=\"login\" type=\"button\" onClick=\"action('list');\" value =\"Aceptar\">
			</div>";
			die();
		}	
			
		

		
		$result = mysql_query("SELECT ID FROM `vote_table` 
							WHERE `account_id` = '$account_id' 
							AND `votelink` = '$id_top' 
							AND `ip` = '$ip'  
							AND `time` > (" . time() . "-43200)");
		$rows = mysql_num_rows($result);
		
		if($rows){ 
		// VOTO IN-CORRECTO
			include("themes/$theme/template/vote_off.php");
		}
		
		else {
			mysql_query("
						INSERT INTO `vote_table`(`account_id`, `ip`, `votelink`, `time`) VALUES (
						'$account_id',  
						'$ip', 
						'$id_top', 
						'" . time() . "' )") 
					or die(mysql_error());
					
		// VOTO CORRECTO
			include("themes/$theme/template/vote_on.php");
		}		
		
	break;
		
	case "logout":	
		
		session_unset();
		session_destroy();
		theme_login();

	break;
	
	
	default:
	
		if( $_SESSION["online"] != "1") {
			theme_login();
		}
		else{
			theme_vote_list();
		}
	break;
	
}	
echo "</div>";
include("footer.php");
?>