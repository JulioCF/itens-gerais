<?php

/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/
	
$url = $_SERVER["REQUEST_URI"];
if (eregi("(\./)|(\.%2F)|(:%2F%2F)|(%3A)|(<)|(>)|(%3C)|(%3E)|(ftp)|(pwd)|(union)|(/\*.*\*/)|(%25)|(dW5pb24)|(VU5JT04)",$url)){
$url2 = base64_encode($url);
die("por seguridad tu ip a sido guardada en el registro");
}	
	
function get_theme (){
global $theme;
	$theme=$_COOKIE["theme"];
	if(isset($theme)) {
		if( file_exists("theme/$theme/theme.php") ){
		$theme=$_COOKIE["theme"];
		}	else {
				//setcookie("theme", "default", time() + (60 * 60 * 24 * 90));
				$theme="default";
			}
	} else {
		setcookie("theme", "default", time() + (60 * 60 * 24 * 90));
		$theme="default";
	   }
	
	return ($theme);
}

 
function obtener_ip(){
//Tomado de webviz
//global $HTTP_CLIENT_IP, $REMOTE_ADDR, $HTTP_X_FORWARDED_FOR;
global $ip;
$ip = false;
if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
	$ip = $_SERVER['HTTP_CLIENT_IP'];
	}

elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
	$ips = explode(", ", $_SERVER['HTTP_X_FORWARDED_FOR']);
	if($ip){
		array_unshift($ips, $ip);
		$ip = false;
		}
	for($i = 0; $i < count($ips); $i++){
	if(!preg_match("/^(10|172\.16|192\.168)\./i", $ips[$i])){
		if(version_compare(phpversion(), "5.0.0", ">=")){
			if(ip2long($ips[$i]) != false){
				$ip = $ips[$i];
			break;
			}
		}
		else {
			if(ip2long($ips[$i]) != - 1){
				$ip = $ips[$i];
			break;
			}	
		}
	}
	}
}
elseif(!empty( $_SERVER ['HTTP_VIA'] ) ){
	$ip = $_SERVER ['HTTP_VIA'];
}
elseif(!empty( $_SERVER ['REMOTE_ADDR'] ) ){
$ip = $_SERVER ['REMOTE_ADDR'];
}
return ($ip ? $ip : $_SERVER['REMOTE_ADDR']);
}



function query($query){
global $result,$row,$num;
$result       = mysql_query("$query") or die(mysql_error());
$row          = mysql_fetch_array( $result );
$num          = mysql_num_rows($result);
}


function points(){
//$_SESSION['username']
$query = "SELECT value FROM global_reg_value WHERE str = '#CASHPOINTS' AND `account_id` = '" . mysql_real_escape_string($_SESSION['username']) . "' LIMIT 1";
$result= mysql_query($query) or die (mysql_error());
$result2 = @mysql_result($result,0);
$result_total = mysql_query("SELECT * FROM vote_table WHERE account_id = '" . mysql_real_escape_string($_SESSION['account_id']) . "' AND collected = '0' ");
$num_rows = @mysql_num_rows($result_total);
$result2=$result2+$num_rows;

if (!$result2) {
	return 0;
}
else
	return ($result2);
}

function top_list() {
global $result_top;
$query_top = "SELECT * FROM vote_list ORDER by id ASC";
$result_top = mysql_query($query_top) or die (mysql_error()) ;
$ruta = get_theme (); 
$ip=obtener_ip();

	while ($data = mysql_fetch_array ($result_top,MYSQL_NUM)) {
	
// Revisa si el Link ya fue Votado y los pone DISABLED
// *******************************************************
		$result = mysql_query("SELECT * FROM `vote_table` 
							WHERE `ip` = '$ip' 
							AND `account_id` = '" . mysql_real_escape_string($_SESSION['account_id']) . "'
							AND `votelink` = '" . mysql_real_escape_string($data[0]) . "' 
							AND `time` > (" . time() . "-43200)");
	 	$rows = mysql_num_rows($result);
			if($rows){
				//NO votar
				printf("
				<div class=\"topbtn\" aligin=\"center\">
				<IMG SRC=\"%s\" align=\"absmiddle\" border=\"0\" />
				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<IMG SRC=\"themes/$ruta/img/votado.png\" align=\"absmiddle\" border=\"0\" />&nbsp;
				<div class=\"topname\">%s</div>
				</div>", 
				$data[3],$data[1] );
			}
			else {
				//LISTAR VOTO
				$checar = stripos($data[2], '?');
				if ($checar === false) {
					$sexy = '?TB_iframe=true&height=600&width=800&modal=1';
					}
				else {
					$sexy = '&TB_iframe=true&height=600&width=800&modal=1';
					}
					printf("
						<div class=\"topbtn\" aligin=\"center\">
						<div>
						<a href=\"%s$sexy\" rel=\"sexylightbox\" onclick=\"action('votar',$data[0]);\">
						<IMG SRC=\"%s\" align=\"absmiddle\" border=\"0\" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<IMG SRC=\"themes/$ruta/img/disponible.png\" align=\"absmiddle\" class=\"topenabled\" border=\"0\" />
						</a></div>
						<div class=\"topname\">
						<a href=\"%s\" target=\"_blank\" onclick=\"action('votar',$data[0]);\">
						<IMG SRC=\"themes/$ruta/img/im_off.gif\" align=\"absmiddle\" border=\"0\" />%s</a></div>
						</div>", 
						$data[2], $data[3],$data[2],$data[1] );
			}
    }	
}

function top_list_il(){
$query_top = "SELECT * FROM vote_list ORDER by id ASC";
$result_top = mysql_query($query_top) or die (mysql_error()) ;

$ip=obtener_ip();
echo "<ul>";
while ($data = mysql_fetch_array ($result_top,MYSQL_NUM)) {

// Revisa si el Link ya fue Votado y los pone DISABLED
// *******************************************************
	$result = mysql_query("SELECT * FROM `vote_table` 
							WHERE `ip` = '$ip' 
							AND `account_id` = '" . mysql_real_escape_string($_SESSION['account_id']) . "'
							AND `votelink` = '" . mysql_real_escape_string($data[0]) . "' 
							AND `time` > (" . time() . "-43200)");


	$rows = mysql_num_rows($result);
		
	if($rows){
 		//NO votar
		printf("<div id=\"lidisable\"><li>%s</li></div>",$data[1]);
		}
	else {
		//LISTAR VOTO
		printf("<li onclick=\"action('votar',%s);\"><a href=\"%s\" target=\"popup\" onClick=\"window.open(this.href, this.target, 'width=700,height=400'); return false;\">%s</a></li>",$data[0],$data[2],$data[1]);
		}	
	}
echo "</ul>";
}

function admin_list(){
$query_admin = "SELECT * FROM vote_list ORDER by id ASC";
$result_admin = mysql_query($query_admin) or die (mysql_error()) ;
$i = 0;
echo "
	<table border=\"0\" cellpadding=\"1\" cellspacing=\"1\" width=\"100%\" id=\"admin\">
	<tbody>
	<tr>
	<td width=\"42\" align=\"center\" class=\"adtoph\"><b> ID </b></td>
	<td align=\"center\" width=\"100\" class=\"adtoph\"><b> Nombre </b></td>
	<td width=\"40\" align=\"center\" class=\"adtoph\"><b> Editar </b></td>
	<td width=\"40\" align=\"center\" class=\"adtoph\"><b> Borrar </b></td>
	</tr>";

	while( $data = mysql_fetch_array ($result_admin,MYSQL_NUM) ){
		//id,name,url,img
		$id = $data[0];
		$name = $data[1];
		echo "
		<tr>
		<td align=\"center\" class=\"adtopc\">$id</td>
		<td align=\"center\" class=\"adtopc\"><b>$name</b></td>
		<td align=\"center\" class=\"adtopc\"><p onclick=\"admin('edit','edit','$id');\"><img src=\"imagenes/edit.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"Edit\"></p></td>
		<td align=\"center\"><p onclick=\"admin('delte','delte','$id');\"><img src=\"imagenes/delete.gif\" width=\"16\" height=\"16\" border=\"0\" alt=\"Delte\"></p></td>
		</tr>";
		++$i;
	}
	
	if ($i == '0'){
		echo '<tr><td colspan="11" align=center>No Exiten Tops</td></tr>';
	}
echo "</tbody></table>";
}


function admin_add(){
echo "
	<form>
	<table border=\"0\" cellpadding=\"0\" cellspacing=\"5\" class=\"adagre\" width=\"100%\">
	<tbody>
	<tr>
	<td colspan=\"2\"><h2>Agregar Top</h2></td></tr>
	<tr>
	<td align=\"right\">
		
	Nombre del Top:</td>
	<td><input class=\"imput\"  id=\"top_name\" name=\"top_name\" type=\"text\" value=\"\" maxlength=\"100\"/></td>
	</tr>
	<tr>
	<td align=\"right\">URL:</td>
	<td><input class=\"imput\"  id=\"top_url\" name=\"top_url\" type=\"text\" value=\"\" maxlength=\"100\"/></td>
	</tr>
	<tr>
	<td align=\"right\">Imagen:</td>
	<td><input class=\"imput\" id=\"top_img\" name=\"top_img\" type=\"text\" value=\"\" maxlength=\"100\" /></td>
	</tr>
	<tr>
	<td colspan=\"2\" align=\"center\">		  
	<input name=\"save\" type=\"button\" onclick=\"admin('add','save');\" value =\"Agregar\" id=\"save\">
	</td>
	</tr>
	</tbody>
	</table>
	</form>";
}

function admin_edit(){
$id = htmlspecialchars($_GET["id"]);
$query = "SELECT * FROM vote_list WHERE id='$id'";
//query($query);
$result = mysql_query($query) or die (mysql_error()) ;
$row = mysql_fetch_array ($result);
//id ,name ,url,img
$id = $row['0'];
$name = $row['1'];
$url = $row['2'];
$img = $row['3'];

echo "
	
	<form>
	<table border=\"0\" cellpadding=\"0\" cellspacing=\"5\" class=\"adedit\" width=\"100%\">
	<tbody>
	<tr><td colspan=\"2\"><h2>EDITAR</h2></td>     <!-- <td>$id</td>	--> </tr>
	<tr>
	<td align=\"right\">Nombre del Top:</td>
	<td><input class=\"imput\"  id=\"top_name\" name=\"top_name\" type=\"text\" value=\"$name\" /></td>
	</tr>
	<tr>
	<td align=\"right\">URL:</td>
	<td><input class=\"imput\"  id=\"top_url\" name=\"top_url\" type=\"text\" value=\"$url\" /></td>
	</tr>
	<tr>
	<td align=\"right\">Imagen:</td>
	<td><input class=\"imput\" id=\"top_img\" name=\"top_img\" type=\"text\" value=\"$img\" /></td>
	</tr>
	<tr>
	<td colspan=\"2\" align=\"center\">		  
	<input name=\"edit\" type=\"button\" onclick=\"admin('edit','update','$id');\" value =\"Editar\" id=\"edit\">
	</td>
	</tr>
	</tbody>
	</table>
	</form>";
}	
	
?>
