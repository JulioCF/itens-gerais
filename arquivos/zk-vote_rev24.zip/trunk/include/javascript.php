<?php
//Vamos soy nuevo en AJAX, se que puede hacer mejor, tal vez solo JAVA (window.location) seria mas sencillo pero lo dejare para futuras actualizaciones
	echo "
	
		<script type=\"text/javascript\">
		function ajaxFunction(top,votar){
			var xmlhttp;
			if (window.XMLHttpRequest){
				// code for IE7+, Firefox, Chrome, Opera, Safari
				xmlhttp=new XMLHttpRequest();
			}
			else if (window.ActiveXObject)
			{
			// code for IE6, IE5
			xmlhttp=new ActiveXObject(\"Microsoft.XMLHTTP\");
			}
			else
			{
			alert(\"Your browser does not support XMLHTTP!\");
			}
		xmlhttp.onreadystatechange=function() {
			if(xmlhttp.readyState==4) {
				var divc = document.getElementById('vote');
				var result = xmlhttp.responseText.split('[:]');
				divc.innerHTML = result[0];

				}
			}
			
		var url=\"./index.php\";
		url=url+\"?action=votar\";
		url=url+\"&op=\"+top;
		url=url+\"&sid=\"+Math.random();	
		xmlhttp.open(\"GET\",url,true);
		xmlhttp.send(null);
		}
		
		</script>";
?>