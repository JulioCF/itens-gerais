
/********************************************************************************/
/* ZK-vote: Sistema de Votaciones						        				*/
/* ==============================			                                    */
/*                                                                              */
/*    Copyright (C) 2009  by ZRO and Kaneda                                     */
/*    http://zk-vote.sourceforge.net                                            */
/*                                                                              */  
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*   You should have received a copy of the GNU General Public License          */
/*   along with this program.  If not, see <http://www.gnu.org/licenses/>.      */
/********************************************************************************/

function objeto_ajax(){
	var xmlhttp;
		if (window.XMLHttpRequest){
			// code for IE7+, Firefox, Chrome, Opera, Safari
			xmlhttp=new XMLHttpRequest();
		}
		else if (window.ActiveXObject)
		{
			// code for IE6, IE5
			xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		}
		else
		{
			alert("Your browser does not support XMLHTTP!");
		}
	return 	xmlhttp;
	}

var ajax = objeto_ajax();
function action(step,top){

	var url="./index.php";
	url=url+"?action="+step;
	var sid = Math.random();
	var divc = document.getElementById('cuerpo');
	if (step == "login" ){
		var userid= encodeURI(document.getElementById('userid').value);
		var user_pass = encodeURI(document.getElementById('user_pass').value);
		url=url+"&userid="+userid;
		url=url+"&user_pass="+user_pass;
		url=url+"&sid="+Math.random();
	}
	else if(step == "votar"){
		divc = document.getElementById('invote');
		url=url+"&op="+top;
		url=url+"&sid="+Math.random();
	}
	 //alert(step);
	 
	ajax.onreadystatechange=function() {
		
		if(ajax.readyState==4) { 
			var mostrar = ajax.responseText;
			divc.innerHTML = mostrar;
		}
	//	else
	//	{
	//	divc.innerHTML = "<img src='imagenes/loader.gif'><br><br><p>Espere un momento por favor.</p>";
	//	}
	}
	
	
	ajax.open("GET",url,true);
	ajax.send(null);
}

function admin(step,sub,id){
	url="./index.php?action=gm";
	url=url+"&op="+step;

	if(step == "add"){
		if(sub == "save"){
			var top_name = encodeURI(document.getElementById('top_name').value);
			var top_url = encodeURI(document.getElementById('top_url').value);
			var top_img = encodeURI(document.getElementById('top_img').value);
			url=url+"&sub="+sub;
			url=url+"&top_name="+top_name;
			url=url+"&top_url="+top_url;
			url=url+"&top_img="+top_img;
		}	
		url=url+"&sid="+Math.random();
	}
	else if(step == "edit"){
		url=url+"&id="+id;
		if(sub == "update"){
			var top_name = encodeURI(document.getElementById('top_name').value);
			var top_url = encodeURI(document.getElementById('top_url').value);
			var top_img = encodeURI(document.getElementById('top_img').value);
			url=url+"&sub="+sub;
			url=url+"&top_name="+top_name;
			url=url+"&top_url="+top_url;
			url=url+"&top_img="+top_img;
		}	
		
		url=url+"&sid="+Math.random();
	}
	
	else if(step == "delte"){
		
	if( confirm("Estas seguro de borrar?") ){
		url=url+"&id="+id;
		url=url+"&sub="+sub;
		}	
	url=url+"&sid="+Math.random();
	}
	
	
	ajax.onreadystatechange=function() {
		var divc = document.getElementById('blacon');
		if(ajax.readyState==4) { 
			var mostrar = ajax.responseText;
			divc.innerHTML = mostrar;
		}
		else
		{
		divc.innerHTML = "<img src='imagenes/loader.gif'><br><br><p>Espere un momento por favor.</p>";
		}
	}	
	ajax.open("GET",url,true);
	ajax.send(null);	
}	
