

-- 
-- Estructura de tabla para la tabla `vote_list`
-- 

CREATE TABLE `vote_list` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `url` varchar(150) NOT NULL,
  `img` varchar(150) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `vote_list`
-- 

INSERT INTO `vote_list` VALUES (0, 'ZK-Vote', 'http://zk-vote.sourceforge.net/', 'themes/default/img/logoweb.png');

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `vote_table`
-- 

CREATE TABLE `vote_table` (
  `ID` int(5) NOT NULL auto_increment,
  `account_id` varchar(23) NOT NULL,
  `ip` varchar(21) NOT NULL,
  `votelink` tinyint(2) NOT NULL,
  `time` int(11) NOT NULL,
  `collected` tinyint(2) NOT NULL default '0',
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- Volcar la base de datos para la tabla `vote_table`
-- 

