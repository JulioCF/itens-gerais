ALTER TABLE `cp_querylog` DROP KEY `action_id`;
