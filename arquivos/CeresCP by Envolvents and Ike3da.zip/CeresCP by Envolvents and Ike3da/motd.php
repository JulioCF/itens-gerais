﻿<?php
/*
Ceres Control Panel

This is a control pannel program for Athena and Freya
Copyright (C) 2005 by Beowulf and Nightroad

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

To contact any of the authors about special permissions send
an e-mail to cerescp@gmail.com
*/

session_start();
include_once 'config.php'; // loads config variables
include_once 'query.php'; // imports queries
include_once 'functions.php';

opentable('Seja bem-vindo ao SEU SERVIDOR, Para mudar o nome vá em MOTD.PHP!');
?>
        <link rel="stylesheet" type="text/css" href="envolvents.css">
		<script type="text/javascript" src="envolvents.js"></script>
<META http-equiv=Content-Type content="text/html; charset=iso-8859-1">
<style type="text/css">

img { border:0; }
img a { border:0; }

img.inv{
    filter: alpha(opacity=100); /* internet explorer */
    opacity: 1;           /* fx, safari, opera, chrome */
}

img.inv:hover {
    filter: alpha(opacity=60); /* internet explorer */
    opacity: 0.6;           /* fx, safari, opera, chrome */
}

a { text-decoration: none; }
a:hover { text-decoration: none; }

@font-face {
font-family: 'ikeda';
src: url('my.eot');
src: url('my.eot?#iefix') format('embedded-opentype'),
url('my.ttf') format('truetype');
font-weight: normal;
font-style: normal;
}

#centro-cp { width: 510px; text-align: center; margin: 0 auto; margin-bottom:10px; }



</style>

<table width="514">
<div id="centro-cp">
<div style="height:10px;"></div>
<div style="font:18px ikeda, tahoma; color:#33b6bb;"></div>
<div style="height:10px;"></div>
</div> <!-- centro cp -->
<div style="height:10px;"></div>
</table>
<?php
closetable();
fim();
?>
