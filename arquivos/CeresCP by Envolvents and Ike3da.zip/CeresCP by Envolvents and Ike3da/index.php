﻿<?php

extension_loaded('mysqli')
	or die ("Mysqli extension not loaded. Please verify your PHP configuration.");

is_file("./config.php")
	or die("<a href=\"./install/install.php\">Run Installation Script</a>");

session_start();
include_once 'config.php'; // loads config variables
include_once 'query.php'; // imports queries
include_once 'functions.php';

$_SESSION[$CONFIG_name.'castles'] = readcastles();
$_SESSION[$CONFIG_name.'jobs'] = readjobs();

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
		<title>
			<?php echo htmlformat($CONFIG_name); ?> - Painel de Controle
		</title>
		<!------- CeresCP -------->
		<link rel="stylesheet" type="text/css" href="./ceres.css">
		<script type="text/javascript" src="./ceres.js"></script>
		<!------- Ike3da -------->
        <link rel="stylesheet" type="text/css" href="ikeda.css">
		<!------- Envolvents -------->
        <link rel="stylesheet" type="text/css" href="inc/css/envolvents.css">
		<script type="text/javascript" src="inc/js/envolvents.js"></script>
		<script type="text/javascript" src="inc/js/jquery-1.7.1.min.js"></script>
		<script type="text/javascript" src="inc/js/jquery.ez-bg-resize.js" type="text/javascript"></script>
	</head>

	<body>
<script type="text/javascript">
$(document).ready(function() {
            $(".soc").toggle(function(){
                $(".social").css({opacity : 1,'margin-top' : '-100px',display : 'block'}).animate({'margin-top' : -16,opacity : 1});
                },function(){
                     $(".social").css({opacity : 1,'margin-top' : '-16px',display : 'block'}).animate({'margin-top' : -100,opacity : 1});
                });
});
</script>
    <div class="social" style="display: block; right: 0px;">
    <ul>
    <li><a href="https://twitter.com/" target="_blank"><img src="inc/img/tt.png" /></a></li>
    <li><a href="http://fb.me/" target="_blank"><img src="inc/img/fb.png" /></a></li>
    <li class="soc"><img src="inc/img/seta.png" /></li>
    </ul>
   </div>
    <div style="width:100%; top:0%; margin:0; height:40px; background:#252525;">

        <div style="margin:0 auto; width:1000px; height:22px; margin-top:0px;">
        
        <ul style="margin:0; color:#cbcbcb; font: 10px tahoma; text-align: center;">
        <div style="float:left; display: inline; height:15px; width: 25px;"></div>
        
        <div id="menutopo"><div style="height:14px;"></div>
        <a href="#">Site Oficial</a></div>
        
        <div id="menutopo">
        <div style="height:14px;"></div>
        <a href="#">Download</a>
        </div>
        
		<div id="menutopo">
        <div style="height:14px;"></div>
		<a href="#">Informa&ccedil;&otilde;es</a>
        </div>
        
        <div id="menutopo">
        <div style="height:14px;"></div>
        <a href="#">Ranking</a>
        </div>
        
        <div id="menutopo">
        <div style="height:14px;"></div>
        <a href="#">Fazer Doação</a>
        </div>
        
        <div id="menutopo">
        <div style="height:14px;"></div>
        <a href="#" target="_blank">Fórum</a>
        </div>
        
        
   </ul>
    	</div>
        
    </div>    
 
 <div style="background:url(images/bg-2.jpg) center top no-repeat; margin:0 auto; margin-top:0;" >
 
     	<div style="margin:0 auto; height:386px; width: 950px; background:url(images/.png) right bottom no-repeat; ">
                        
    <div style=" float:right; height:143px; width: 235px; background:url(images/status-bg.png) top left; margin-top:183px; margin-right:225px;">
    			
    
    <div id="status_div" style=" text-align:center; line-height:8px; margin-left: 55px;margin-top:30px; width:130px; color:#FFF; height:80px;"></div>
    		
				
     
     </div>
    	</div>

    <div style=" width: 1060px; margin:0 auto; background-color:#252525; -moz-border-radius: 10px;-webkit-border-radius: 10px;">
    
    <div style="height:5px;"></div>
    
		<table border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="height:100%" width="1000" align="center">
        			<tr>
			</tr>
            
			<tr>
				<td style="height:25px" colspan="5" bgcolor="#252525" width="100%">
					<div id="main_menu" style="color:#7f9fb2; font-weight:bold"></div>
					<div id="load_div" style="position:absolute; top:620px; left:600px; height:45px; width:110px; visibility:hidden; background-color:; color:#FFFFFF"><img src="images/loading.gif" alt="Loading..."></div>
					<div id="menu_load" style="position:absolute; top:0px; left:0px; visibility:hidden;"></div>
				</td>
			</tr>
			<tr>
				<td style="height:25px" colspan="5" bgcolor="#DDDDDD"  width="100%">
					<div id="sub_menu" style="color:#4090b9; font-weight:bold">&nbsp;</div>
				</td>
			</tr>
			<tr valign="top">
				<td height="100%">
					<table border="0" width="100%" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" style="height:350px">
						<tr style="height:100%">

<td bgcolor="" valign="top" width="200" rowspan="5" style="height:100%">
<div id="bg-hover">

<div style="magin-top:5px;"></div>

<div id="login_div" style="padding-left: 8; padding-right:6px; padding-top: 10;">
</div>

<div id="new_div" style="padding-left: 8; padding-right:6px; padding-top: 10;"></div>
<div style="height:10px;"></div>
                                 
</div>   
                     
</td>

<td valign="top" bgcolor="#FFFFFF" colspan="2" width="600" style="height:100%">
<div id="main_div" style="padding-left: 15; text-align:center; padding-right: 5; padding-top: 10">
</div>
</td>

<td bgcolor="#EEEEEE" valign="top" width="200" rowspan="5" style="height:100%">
<div style="width:100%; height:100%; background:url(images/javotou.png) center bottom no-repeat;">

<div style="margin:5px;">

<div style="font: bold 12px verdana; text-align: center; margin-bottom: 10px;">Ajude-nos Votando</div>
<div style="font: bold 12px verdana; text-align: center; margin-bottom: 10px;">Vote Point!</div>

<div style="text-align: center;">
<a href="vote.php?site=1" target="_blank"><img src="images/topBR.jpg" border="0" title="Vote em nosso servidor!"/></a>
<div style="height:10px;"></div>
<a href="vote.php?site=2" target="_blank"><img src="images/topORG.jpg" border="0" title="Vote em nosso servidor!"/></a>
<div style="height:10px;"></div>
<a href="vote.php?site=3" target="_blank"><img src="images/top200.jpg" border="0" title="Vote em nosso servidor!"/></a>
                                
                                </div>
								 <div style="height:10px;"></div>
                                </div>
                                </div> <!-- bg -->
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td colspan="5" bgcolor="#252525" style="height:40px" valign="middle" align="center">
					<p style="font-size: 9px; margin-top: 7"><font color="#FFFFFF">
						Todos os direitos reservados © 2013<br>
						<span style="cursor:pointer" class="copyright_link" onClick="window.open('http://cerescp.sourceforge.net/');">
						Ceres Control Panel</span> by Beowulf and Dekamaster
						<!-- Se você remover qualquer nome nunca mais vou disponibilizar uma CeresCP, aliás nenhum painel que seja modificado por mim! -->
						<br>Personalizado por <span style="cursor: pointer; color: #C03;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#C03'" onclick="window.open('http://k3sign.com');">Ike3da</span> & <span style="cursor: pointer; color: #C03;" onmouseover="this.style.color='#fff'" onmouseout="this.style.color='#C03'" onclick="window.open('http://www.wellingtonferraz.com');">Envolvents</span></font></p>
						<!-- Se você remover qualquer nome nunca mais vou disponibilizar uma CeresCP, aliás nenhum painel que seja modificado por mim! -->
				</td>
			</tr>
		</table>
        
        </div> 
		<!-- bg-2 -->
        
                <div style="margin:0 auto; width:1060px; height:132px; background:url(images/baixo-lay.png) no-repeat;"></div>
                
                
		<script type="text/javascript">
			load_menu();
			LINK_ajax('motd.php', 'main_div');
			LINK_ajax('login.php', 'login_div');
			login_hide(2);
			server_status()
			LINK_ajax('selectlang.php', 'selectlang_div');
		</script>
        </div>
	</body>
</html>

<?php
fim();
?>
